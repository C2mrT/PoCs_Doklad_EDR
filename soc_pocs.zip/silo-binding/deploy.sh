#!/usr/bin/env bash
#
# Deploy the built PoC to the Windows lab VM over SMB and optionally run a
# command through VirtualBox guest control.
#
#   VM=Windows10Kasper VMHOST=192.168.56.10 VMUSER=Administrator VMPASS='Passw0rd!' \
#       ./deploy.sh
#   ./deploy.sh demo          # deploy, then run `silobind.exe demo`
#
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"

VM="${VM:-Windows10Kasper}"
VMHOST="${VMHOST:-192.168.56.10}"
VMUSER="${VMUSER:-Administrator}"
VMPASS="${VMPASS:-Passw0rd!}"
DEST_WIN='C:\ProgramData\silobind'
DEST_UNIX='ProgramData/silobind'

mkdir -p "$here/out"
[ -f "$here/out/silobind.exe" ] || "$here/build.sh"

echo "[*] uploading to //$VMHOST/$DEST_UNIX"
smbclient "//$VMHOST/C\$" -U "$VMUSER%$VMPASS" -c "mkdir ${DEST_UNIX//\//\\}"  >/dev/null 2>&1 || true
smbclient "//$VMHOST/C\$" -U "$VMUSER%$VMPASS" \
    -c "put $here/out/silobind.exe $DEST_UNIX/silobind.exe; put $here/out/payload.exe $DEST_UNIX/payload.exe" \
    >/dev/null
echo "[*] done. files at $DEST_WIN"

if [ "${1:-}" = "demo" ]; then
    echo "[*] running demo on the guest..."
    VBoxManage guestcontrol "$VM" run \
        --exe "$DEST_WIN\\silobind.exe" \
        --username "$VMUSER" --password "$VMPASS" \
        -- demo
fi
