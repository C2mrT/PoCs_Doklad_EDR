/*
 * bindflt.h - Bind Filter (bindflt.sys) driver definitions.
 *
 * Adapted for this PoC from the publicly released Bitdefender Labs toolset:
 *   https://github.com/bitdefender/bindutil-toolset   (BSD-3-Clause)
 * and from the Microsoft/hcsshim/Nukem9 public descriptions of the
 * undocumented \BindFltPort message protocol.
 *
 * These structures describe the *raw* filter-port interface. They are only
 * used when the documented bindfltapi.dll entry points are unavailable
 * (e.g. WoW64). On the lab target (Windows 10 19045 x64) the DLL interface
 * is used by default.
 */
#ifndef _BINDFLT_H_INCLUDED_
#define _BINDFLT_H_INCLUDED_

#include <windows.h>
#include <stdint.h>

#ifndef EXTERN_C_START
#ifdef __cplusplus
#define EXTERN_C_START extern "C" {
#define EXTERN_C_END }
#else
#define EXTERN_C_START
#define EXTERN_C_END
#endif
#endif

EXTERN_C_START

/* Flags for BfSetupFilter / BfSetupFilterEx. */
typedef enum _BINDFLT_SETUP_FILTER_FLAGS
{
    BINDFLT_FLAG_NONE                         = 0x00000000,
    BINDFLT_FLAG_READ_ONLY_MAPPING            = 0x00000001,
    BINDFLT_FLAG_MERGED_BIND_MAPPING          = 0x00000002,
    BINDFLT_FLAG_USE_CURRENT_SILO_MAPPING     = 0x00000004,
    BINDFLT_FLAG_REPARSE_ON_FILES             = 0x00000008,
    BINDFLT_FLAG_SKIP_SHARING_CHECK           = 0x00000010,
    BINDFLT_FLAG_CLOUD_FILES_ECPS             = 0x00000020,
    BINDFLT_FLAG_NO_MULTIPLE_TARGETS          = 0x00000040,
    BINDFLT_FLAG_IMMUTABLE_BACKING            = 0x00000080,
    BINDFLT_FLAG_PREVENT_CASE_SENSITIVE_BINDING = 0x00000100,
    BINDFLT_FLAG_EMPTY_VIRT_ROOT              = 0x00000200,
    BINDFLT_FLAG_NO_REPARSE_ON_ROOT           = 0x10000000,
    BINDFLT_FLAG_BATCHED_REMOVE_MAPPINGS      = 0x20000000,
} BINDFLT_SETUP_FILTER_FLAGS;

typedef enum _BINDFLT_GET_MAPPINGS_FLAGS
{
    BINDFLT_GET_MAPPINGS_FLAG_VOLUME = 0x00000001,
    BINDFLT_GET_MAPPINGS_FLAG_SILO   = 0x00000002,
    BINDFLT_GET_MAPPINGS_FLAG_USER   = 0x00000004,
} BINDFLT_GET_MAPPINGS_FLAGS;

typedef struct _BINDFLT_GET_MAPPINGS_TARGET_ENTRY
{
    UINT32 TargetRootLength;
    UINT32 TargetRootOffset;
} BINDFLT_GET_MAPPINGS_TARGET_ENTRY, *PBINDFLT_GET_MAPPINGS_TARGET_ENTRY;

typedef struct _BINDFLT_GET_MAPPINGS_ENTRY
{
    UINT32 VirtRootLength;
    UINT32 VirtRootOffset;
    UINT32 Flags;
    UINT32 NumberOfTargets;
    UINT32 TargetEntriesOffset;
} BINDFLT_GET_MAPPINGS_ENTRY, *PBINDFLT_GET_MAPPINGS_ENTRY;

typedef struct _BINDFLT_GET_MAPPINGS_INFO
{
    UINT32 Size;                /* returned size of this output structure */
    LONG   Status;              /* NTSTATUS result */
    UINT32 MappingCount;        /* number of BINDFLT_GET_MAPPINGS_ENTRY elements */
    BINDFLT_GET_MAPPINGS_ENTRY Entries[1];
} BINDFLT_GET_MAPPINGS_INFO, *PBINDFLT_GET_MAPPINGS_INFO;

/* Command codes extracted from bindflt!BfPortMessage. */
typedef enum _BINDFLT_COMMAND_CODE
{
    BFC_STORE_MAPPING                = 0,
    BFC_STORE_MAPPING_REPLY          = 1,
    BFC_REMOVE_MAPPING               = 2,
    BFC_REMOVE_MAPPING_REPLY         = 3,
    BFC_STORE_MAPPING_BATCHED        = 4,
    BFC_STORE_MAPPING_BATCHED_REPLY  = 5,
    BFC_REMOVE_MAPPING_BATCHED       = 6,
    BFC_REMOVE_MAPPING_BATCHED_REPLY = 7,
    BFC_GET_MAPPINGS                 = 8,
    BFC_GET_MAPPINGS_REPLY           = 9,
    BFC_TRACK_SILO_WRITES            = 10,
    BFC_TRACK_SILO_WRITES_REPLY      = 11,
} BINDFLT_COMMAND_CODE;

/* Paths normalized by bindflt via FSCTL_SET_LAYER_ROOT. */
typedef struct _BINDFLT_NORMALIZED_PATH
{
    UINT16 CbSize;
    UINT16 VolumeNameSize;
    UINT16 FullNameSize;
    WCHAR  Name[1];
} BINDFLT_NORMALIZED_PATH, *PBINDFLT_NORMALIZED_PATH;

typedef struct _BINDFLT_MSG_HEADER
{
    UINT32 Command;
    UINT32 CbSize;              /* sizeof(header) + sizeof(following message) */
} BINDFLT_MSG_HEADER, *PBINDFLT_MSG_HEADER;

/* Sent by bindfltapi!bfraw::BfSetupFilterInternal. */
typedef struct _BINDFLT_STORE_MAPPING_MSG
{
    UINT32 CbSize;
    UINT32 ExceptionsArrayCount;
    UINT32 Flags;
    UINT32 Unk1_MaybePadding;
    UINT64 JobHandle;               /* HANDLE widened for WoW */
    UINT64 Sid;                     /* PSID widened for WoW */
    UINT16 DirectoryNameLen;
    UINT16 Unk2_MaybePadding;
    UINT32 ExceptionsOffset;
    UINT32 VirtualizationRootOffset;
    UINT32 VirtualizationRootSize;
    UINT32 VirtualizationTargetOffset;
    UINT32 VirtualizationTargetSize;
    UINT32 Unk3_MaybePadding;
    UINT8  Data[1];                 /* Exceptions / serialized normalized paths */
} BINDFLT_STORE_MAPPING_MSG, *PBINDFLT_STORE_MAPPING_MSG;

/* Sent by bindfltapi!bfraw::BfRemoveMappingInternal. */
typedef struct _BINDFLT_REMOVE_MAPPING_MSG
{
    UINT32 CbSize;
    UINT32 Unk1_MaybePadding;
    UINT64 JobHandle;
    UINT64 Sid;
    UINT16 DirectoryNameLen;
    UINT16 Unk2_MaybePadding;
    UINT32 DirectoryNameOffset;
    UINT16 VirtualizationRootOffset;
    UINT16 Unk3_MaybePadding;
    UINT32 VirtualizationRootSize;
    UINT8  Data[1];
} BINDFLT_REMOVE_MAPPING_MSG, *PBINDFLT_REMOVE_MAPPING_MSG;

#pragma pack (push, 1)
typedef struct _BINDFLT_GET_MAPPING
{
    BINDFLT_MSG_HEADER Header;
    UINT32 DataSize;
    UINT32 GetMappingFlags;
    UINT64 FileHandle;
    UINT64 JobHandle;
    UINT64 Sid;
    UINT32 Unk1_MaybePadding;
} BINDFLT_GET_MAPPING;
#pragma pack (pop)

/* ---- bindfltapi.dll exports (documented API layer) ---- */
typedef HRESULT (WINAPI *pfnBfSetupFilter)(
    HANDLE  JobHandle,
    ULONG   Flags,
    LPCWSTR VirtualizationRootPath,
    LPCWSTR VirtualizationTargetPath,
    LPCWSTR *VirtualizationExceptionPaths,
    ULONG   VirtualizationExceptionPathCount);

typedef HRESULT (WINAPI *pfnBfSetupFilterEx)(
    ULONG   Flags,
    HANDLE  JobHandle,
    PSID    Sid,
    LPCWSTR VirtualizationRootPath,
    LPCWSTR VirtualizationTargetPath,
    LPCWSTR *VirtualizationExceptionPaths,
    ULONG   VirtualizationExceptionPathCount);

typedef HRESULT (WINAPI *pfnBfRemoveMapping)(HANDLE JobHandle, LPCWSTR VirtualizationRootPath);
typedef HRESULT (WINAPI *pfnBfRemoveMappingEx)(HANDLE JobHandle, PSID Sid, LPCWSTR VirtualizationRootPath);
typedef HRESULT (WINAPI *pfnBfGetMappings)(ULONG Flags, HANDLE JobHandle, LPCWSTR VirtualizationRootPath,
                                           PSID Sid, PULONG BufferSize, LPVOID OutBuffer);

/* ---- fltlib.dll (raw filter-port fallback) ---- */
typedef HRESULT (WINAPI *pfnFilterConnectCommunicationPort)(
    PCWSTR lpPortName, ULONG dwOptions, const void *lpContext,
    ULONG dwSizeOfContext, void *lpSecurityAttributes, HANDLE *hPort);
typedef HRESULT (WINAPI *pfnFilterSendMessage)(
    HANDLE hPort, void *lpInBuffer, ULONG dwInBufferSize,
    void *lpOutBuffer, ULONG dwOutBufferSize, ULONG *lpBytesReturned);

EXTERN_C_END

#endif /* _BINDFLT_H_INCLUDED_ */
