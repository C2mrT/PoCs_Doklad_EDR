#!/usr/bin/env bash
#
# Cross-compile the Silo-Binding PoC for Windows with zig.
# Produces out/silobind.exe and out/payload.exe (x86_64, console).
#
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
out="$here/out"
mkdir -p "$out"

echo "[*] building silobind.exe"
zig c++ -target x86_64-windows-gnu -O2 -std=gnu++17 -I"$here/include" \
    -o "$out/silobind.exe" "$here/src/silobind.cpp" -lshell32

echo "[*] building payload.exe"
zig c++ -target x86_64-windows-gnu -O2 -std=gnu++17 \
    -o "$out/payload.exe" "$here/src/payload.cpp"

echo "[*] done:"
ls -la "$out"
