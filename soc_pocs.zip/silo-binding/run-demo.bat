@echo off
rem ---------------------------------------------------------------------------
rem  Silo-Binding PoC - run directly on the Windows lab VM.
rem  Everything happens in ONE process, because a silo lives only as long as
rem  some process keeps its job handle open.
rem ---------------------------------------------------------------------------
setlocal
cd /d "%~dp0"

echo [*] running the full Silo-Binding demo...
silobind.exe demo

echo.
echo [*] bonus: what a file-hashing tool (certutil) sees from OUTSIDE the silo
silobind.exe link "%~dp0payload.exe" "C:\Windows\System32\hostname.exe"
echo     payload.exe hash BEFORE/real file:
certutil -hashfile "%~dp0payload.exe" SHA256
echo     (with the inverse global link in place the hash above is hostname.exe)
silobind.exe unlink "%~dp0payload.exe"

pause
