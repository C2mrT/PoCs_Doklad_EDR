# CET-Compliant Callstack Spoofing PoC

Рабочий PoC техники **CET-совместимой подмены стека** (публичное исследование:
Tiziano Marra / MrTiz, «CET-Compliant Callstack Spoofing via Thread Pool Enum
Callback Trampolining», 12.07.2026). Порт на C++.

Блок доклада: «Call Stack и Intel CET» / «CET-совместимая подмена стека».

## Идея

Три примитива, дающие в момент syscall полностью легитимный стек:

1. **Thread pool** (`CreateThreadpoolWork`) — чистый базовый стек (поток создан ОС).
2. **Enum-callback трамплин** (`EnumSystemLocalesEx`) — реальный кадр подписанного
   модуля на стеке (мы действительно вызываем эту функцию).
3. **Indirect syscall** — `syscall; ret` гаджет внутри `ntdll.dll`, поэтому верхний
   адрес возврата указывает в подписанный модуль.

**CET-совместимость** (`src/user_mode_continue.S`):
- переключение контекста делается `jmp`, а не `ret` (shadow stack при `jmp` не
  задействуется — нет pop, нет сравнения, нет `#CP`);
- указатель shadow stack выравнивается инструкциями `RDSSPQ`/`INCSSPQ` (вход в
  `user_mode_continue` кладёт на shadow stack «лишний» адрес возврата, который надо
  «съесть»);
- если CET выключен, `RDSSPQ` возвращает 0 и reconciliation просто пропускается —
  один и тот же бинарь работает и на CET, и без него.

## Состав

```
cet-shadow-stack/
├── src/cet-spoofing.cpp        # PoC: 3 фазы + печать стека «глазами EDR»
├── src/user_mode_continue.S    # CET-совместимый context switch (RDSSPQ/INCSSPQ + jmp)
├── build.sh
└── README.md
```

## Сборка

```bash
cd cet-shadow-stack
./build.sh        # -> out/cetspoof.exe
```

## Запуск на стенде

```bash
VBoxManage guestcontrol "Windows10Kasper" run \
  --exe "C:\\ProgramData\\cet\\cetspoof.exe" \
  --username "Administrator" --password "Passw0rd!" -- 
```

## Что видно

Стек в момент выполнения `NtProtectVirtualMemory` (как его обойдёт EDR-валкер):

```
#0  ntdll.dll!NtProtectVirtualMemory+0x12     <- syscall;ret трамплин (indirect syscall)
#1  KERNELBASE.dll+0x1b4db                    <- Internal_EnumSystemLocales
#2  KERNELBASE.dll!EnumSystemLocalesEx+0x23   <- реальный кадр enum-функции
#3  ntdll.dll+0x62260                         <- TppWorkpExecuteCallback
#4  ntdll.dll+0x531aa                         <- TppWorkerThread
#5  KERNEL32.DLL!BaseThreadInitThunk+0x14
#6  ntdll.dll!RtlUserThreadStart+0x21
```

Ни одного кадра в неподписанной памяти, ни одного синтетического кадра.

## Что скринить (функции)

- **`user_mode_continue`** (`src/user_mode_continue.S`) — сердце CET-совместимости:
  `RDSSPQ`/`INCSSPQ` reconciliation + `jmp`-переключение контекста.
- **`manual_stack_unwind_enum`** (`src/cet-spoofing.cpp`) — фаза enum-callback:
  ручной unwind, установка регистров syscall, прыжок в трамплин.
- **`thread_pool_worker_enum`** (`src/cet-spoofing.cpp`) — фаза 1: чистый базовый
  стек из thread pool и редирект в enum-функцию.

## Важно про стенд

В этой VM **Intel CET не проброшен** (VirtualBox не отдаёт CET гостю):
`CPUID.7.0.ECX=0`, `IsUserCetAvailableInEnvironment=0`. Поэтому в выводе
`RDSSPQ -> SSP = 0x0 => CET OFF`, а reconciliation — no-op (как и предусмотрено
техникой).

### Чтобы в выводе появилось `CET ON`

Нужна машина с реальным CET (Intel 11-е поколение+ / AMD Zen3+) и Windows 10 20H1+.
VirtualBox CET не пробрасывает — нужен физический хост (или гипервизор, который
CET отдаёт, например KVM/QEMU с `-cpu host`).

Плюс бинарь должен **запросить** Hardware-enforced Stack Protection. Для этого
он помечается как **CETCOMPAT** — эквивалент линкерного ключа MSVC `/CETCOMPAT`
(debug-запись `IMAGE_DEBUG_TYPE_EX_DLLCHARACTERISTICS`, флаг `0x0001`). У zig/mingw
такого ключа нет, поэтому `mark_cetcompat.py` проставляет флаг в PE после сборки
(это уже сделано в `build.sh`).

На CET-машине этого достаточно: ядро заведёт shadow stack, `RDSSPQ` вернёт
ненулевой SSP, и `INCSSPQ`-reconciliation реально отработает. Если по какой-то
причине HSP не включилась, можно включить явно:

```powershell
Set-ProcessMitigation -Name cetspoof.exe -Enable UserShadowStack
```


## Источники

- Tiziano Marra (MrTiz) — *CET-Compliant Callstack Spoofing via Thread Pool Enum
  Callback Trampolining* (2026) + PoC `CET-Enum-CallStack-Spoofer`.
- Intel — Shadow Stack (Intel 64 and IA-32 SDM; CET).
- Microsoft Learn — Hardware-enforced Stack Protection, `PROCESS_MITIGATION_USER_SHADOW_STACK_POLICY`.

## Дисклеймер

Только для авторизованных исследований и лабораторных стендов.
