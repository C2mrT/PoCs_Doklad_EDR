/*
 * cetprobe.cpp - check whether Intel CET / Shadow Stack is actually available
 * inside the guest (CPUID leaf, OS API, process mitigation).
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <intrin.h>

/* PROCESS_MITIGATION_USER_SHADOW_STACK_POLICY and ProcessUserShadowStackPolicy
   are provided by the mingw-w64 headers on this toolchain. */
typedef BOOL (WINAPI *pfnIsUserCetAvailableInEnvironment)(DWORD);

int main(void)
{
    int ci[4] = { 0,0,0,0 };
    __cpuid(ci, 0);
    int maxLeaf = ci[0];
    __cpuidex(ci, 1, 0);
    int family = ((ci[0] >> 8) & 0xF) + ((ci[0] >> 20) & 0xFF);
    int model = ((ci[0] >> 4) & 0xF) | (((ci[0] >> 16) & 0xF) << 4);

    int cet_ss = 0, cet_ibt = 0, raw = 0;
    if (maxLeaf >= 7) {
        __cpuidex(ci, 7, 0);
        raw = ci[2];
        cet_ibt = (ci[2] >> 6) & 1;   /* ECX[6]  = CET_IBT */
        cet_ss = (ci[2] >> 7) & 1;    /* ECX[7]  = CET_SS (shadow stack) */
    }

    printf("CPU          : family %d model %d\n", family, model);
    printf("CPUID.7.0.ECX: 0x%08X   CET_IBT=%d  CET_SS(shadow stack)=%d\n", raw, cet_ibt, cet_ss);

    HMODULE k = GetModuleHandleW(L"kernel32.dll");
    pfnIsUserCetAvailableInEnvironment pIsCet =
        (pfnIsUserCetAvailableInEnvironment)GetProcAddress(k, "IsUserCetAvailableInEnvironment");
    printf("IsUserCetAvailableInEnvironment export present: %s\n", pIsCet ? "yes" : "no");
    if (pIsCet)
        printf("  IsUserCetAvailableInEnvironment(WIN32_PROCESS=1) = %d\n", pIsCet(1));

    PROCESS_MITIGATION_USER_SHADOW_STACK_POLICY p;
    memset(&p, 0, sizeof(p));
    BOOL ok = GetProcessMitigationPolicy(GetCurrentProcess(), ProcessUserShadowStackPolicy, &p, sizeof(p));
    printf("GetProcessMitigationPolicy: ok=%d flags=0x%08X EnableUserShadowStack=%d\n",
           ok, p.Flags, p.EnableUserShadowStack);

    PROCESS_MITIGATION_USER_SHADOW_STACK_POLICY en;
    memset(&en, 0, sizeof(en));
    en.EnableUserShadowStack = 1;
    BOOL sok = SetProcessMitigationPolicy(ProcessUserShadowStackPolicy, &en, sizeof(en));
    printf("SetProcessMitigationPolicy(enable shadow stack): ok=%d err=%lu\n", sok, GetLastError());

    memset(&p, 0, sizeof(p));
    GetProcessMitigationPolicy(GetCurrentProcess(), ProcessUserShadowStackPolicy, &p, sizeof(p));
    printf("after: flags=0x%08X Enable=%d Strict=%d\n", p.Flags, p.EnableUserShadowStack, p.EnableUserShadowStackStrictMode);
    return 0;
}
