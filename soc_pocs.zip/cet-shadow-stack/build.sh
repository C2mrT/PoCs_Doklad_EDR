#!/usr/bin/env bash
#
# Cross-compile the CET-Compliant Callstack Spoofing PoC for Windows with zig.
# Produces out/cetspoof.exe (x86_64, console).
#
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$here/out"

echo "[*] building cetspoof.exe"
zig c++ -target x86_64-windows-gnu -O2 -std=gnu++17 \
    -o "$here/out/cetspoof.exe" \
    "$here/src/cet-spoofing.cpp" \
    "$here/src/user_mode_continue.S" \
    -lntdll

echo "[*] marking CETCOMPAT (equivalent of MSVC /CETCOMPAT)"
python3 "$here/mark_cetcompat.py" "$here/out/cetspoof.exe"

echo "[*] done:"
ls -la "$here/out"
