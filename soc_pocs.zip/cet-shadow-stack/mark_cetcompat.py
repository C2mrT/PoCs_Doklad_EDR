#!/usr/bin/env python3
"""
mark_cetcompat.py <pe-file>

Adds the IMAGE_DEBUG_TYPE_EX_DLLCHARACTERISTICS debug entry carrying the
IMAGE_DLLCHARACTERISTICS_EX_CET_COMPAT (0x0001) flag -- the equivalent of
MSVC's /CETCOMPAT linker switch. With this flag the Windows loader asks the
kernel to maintain an Intel CET shadow stack for the process on CET-capable
hardware, so RDSSPQ returns a non-zero SSP.

The zig/mingw toolchain has no /CETCOMPAT option, so the built PE is patched.
The whole debug directory is relocated into free space inside its section so
the existing CodeView record is left untouched. Idempotent.
"""
import struct
import sys

IMAGE_DEBUG_TYPE_EX_DLLCHARACTERISTICS = 20
CET_COMPAT = 0x0001
ENTRY = 28

def main(path):
    d = bytearray(open(path, "rb").read())
    pe = struct.unpack_from("<I", d, 0x3C)[0]
    nsec = struct.unpack_from("<H", d, pe + 6)[0]
    optsz = struct.unpack_from("<H", d, pe + 20)[0]
    opt = pe + 24
    magic = struct.unpack_from("<H", d, opt)[0]
    dd = opt + (112 if magic == 0x20B else 96)

    dbg_dd = dd + 6 * 8
    dbg_rva, dbg_sz = struct.unpack_from("<II", d, dbg_dd)

    sec_hdr = opt + optsz
    secs = []
    for i in range(nsec):
        b = sec_hdr + i * 40
        vsz, vaddr, rsz, raddr = struct.unpack_from("<IIII", d, b + 8)
        secs.append([b, vaddr, vsz, raddr, rsz])

    def r2o(rva):
        for _, vaddr, vsz, raddr, rsz in secs:
            if vaddr <= rva < vaddr + max(vsz, rsz):
                return raddr + (rva - vaddr)
        raise SystemExit(f"rva 0x{rva:x} not mapped")

    old_off = r2o(dbg_rva)
    entries = [bytes(d[old_off + i * ENTRY: old_off + (i + 1) * ENTRY])
               for i in range(dbg_sz // ENTRY)]
    if any(struct.unpack_from("<I", e, 12)[0] == IMAGE_DEBUG_TYPE_EX_DLLCHARACTERISTICS
           for e in entries):
        print("[=] CETCOMPAT entry already present")
        return

    # section that owns the debug directory
    for sec in secs:
        b, vaddr, vsz, raddr, rsz = sec
        if vaddr <= dbg_rva < vaddr + max(vsz, rsz):
            owner = sec
            break

    # relocate the whole debug directory to fresh, 8-aligned space after it
    new_dir_rva = (owner[1] + owner[2] + 7) & ~7
    new_dir_off = r2o(new_dir_rva)
    blob_rva = new_dir_rva + (len(entries) + 1) * ENTRY
    blob_off = r2o(blob_rva)

    for i, e in enumerate(entries):
        d[new_dir_off + i * ENTRY: new_dir_off + (i + 1) * ENTRY] = e

    d[blob_off:blob_off + 4] = struct.pack("<I", CET_COMPAT)
    struct.pack_into("<IIHHIIII", d, new_dir_off + len(entries) * ENTRY,
                     0, 0, 0, 0,
                     IMAGE_DEBUG_TYPE_EX_DLLCHARACTERISTICS,
                     4, blob_rva, blob_off)

    struct.pack_into("<II", d, dbg_dd, new_dir_rva, (len(entries) + 1) * ENTRY)

    new_vsize = max(owner[2], blob_rva + 4 - owner[1])
    struct.pack_into("<I", d, owner[0] + 8, new_vsize)

    open(path, "wb").write(d)
    print(f"[+] CETCOMPAT entry added; debug dir -> rva 0x{new_dir_rva:x}, blob rva 0x{blob_rva:x}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: mark_cetcompat.py <pe-file>")
    main(sys.argv[1])
