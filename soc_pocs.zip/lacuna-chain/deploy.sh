#!/usr/bin/env bash
#
# Deploy the LACUNA Chain PoC to the Windows lab VM over SMB and optionally run
# a command through VirtualBox guest control.
#
#   VM=Windows10Kasper VMHOST=192.168.56.10 VMUSER=Administrator VMPASS='Passw0rd!' \
#       ./deploy.sh
#   ./deploy.sh scan          # deploy, then run `lacuna.exe scan`   on the guest
#   ./deploy.sh verify        # deploy, then run `lacuna.exe verify` on the guest
#
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"

VM="${VM:-Windows10Kasper}"
VMHOST="${VMHOST:-192.168.56.10}"
VMUSER="${VMUSER:-Administrator}"
VMPASS="${VMPASS:-Passw0rd!}"
DEST_WIN='C:\ProgramData\lacuna'
DEST_UNIX='ProgramData/lacuna'

mkdir -p "$here/out"
[ -f "$here/out/lacuna.exe" ] || "$here/build.sh"

echo "[*] uploading to //$VMHOST/$DEST_UNIX"
smbclient "//$VMHOST/C\$" -U "$VMUSER%$VMPASS" -c "mkdir ${DEST_UNIX//\//\\}" >/dev/null 2>&1 || true
smbclient "//$VMHOST/C\$" -U "$VMUSER%$VMPASS" \
    -c "put $here/out/lacuna.exe $DEST_UNIX/lacuna.exe" >/dev/null
echo "[*] done. file at $DEST_WIN\\lacuna.exe"

if [ -n "${1:-}" ]; then
    echo "[*] running 'lacuna.exe $1' on the guest..."
    VBoxManage guestcontrol "$VM" run \
        --exe "$DEST_WIN\\lacuna.exe" \
        --username "$VMUSER" --password "$VMPASS" \
        -- "$1"
fi
