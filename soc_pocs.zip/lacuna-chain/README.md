# LACUNA Chain — Ghost Frames PoC

Рабочий PoC техники **LACUNA Chain / Ghost Frames** — спуфинг call stack через
исполняемые адреса, у которых **нет записи в `.pdata`** («лакуны»). Публичное
исследование: Mohamed Alzhrani (0xmaz), *«LACUNA Chain: Ghost Frames — defeats all
EDR layers of call-stack-based detection»*, 2026. Опирается на BYOUD (klezVirus,
Black Hat EU 2025) и SilentMoonwalk.

Блок доклада: «Call Stack под нагрузкой: `.pdata`-лакуны» / «Ghost Frames».

## Идея

На x64 нет frame pointer. Стек разматывается по `.pdata`: для каждого кадра
`RtlLookupFunctionEntry` ищет `RUNTIME_FUNCTION`, а `RtlVirtualUnwind` по
`UNWIND_CODE` считает дельту `RSP`. Но есть критичная ветка: **если для адреса
нет `RUNTIME_FUNCTION`, unwinder не падает — он считает кадр leaf-функцией и
просто делает `RSP += 8`** (читает следующий адрес возврата из `[RSP]`).

Между двумя соседними `RUNTIME_FUNCTION` в каждой DLL всегда есть «щели» —
лакуны. Они исполняемы, отмаплены из подписанного образа и неотличимы от
легального leaf-сайта. Если в кадр поставить такой адрес, вал кер/EDR увидит
кадр, которого нет. Ни байта `.pdata` при этом не меняется.

Примитивы, реализованные в этом PoC:

| # | Примитив | Что делает |
|---|----------|------------|
| 1 | **BYOUD-Gap** | кадры из лакун: `RtlLookupFunctionEntry==NULL` → leaf → `RSP+=8` |
| 2 | **Ghost functions** | лакуны, в которых лежит реальный код (в ntdll/winbase их сотни) |
| 3 | **Win32u NOP Gap** | 8-байтные NOP между syscall-стабами win32u — «whitelist-immune» |
| 4 | **Ghost gadget** | `JMP [RBX]` (`FF 23`) внутри ghost-функции — dual-use leaf-адрес |
| 5 | **BYOUD-MF** | `UWOP_PUSH_MACHFRAME` (opcode 10): unwinder читает `RSP` со стека → телепорт `RSP` за один кадр |
| 6 | **BYOUD-RT** | дистанция кадра считается в рантайме из `TEB.StackBase` (`GS:[0x08]`) |

Собранная цепочка (то, что видит коллектор call stack):

```
L0  ntdll!KiUserExceptionDispatcher+…   BYOUD-MF anchor (UWOP_PUSH_MACHFRAME)
L1  wow64.dll   ghost                    тень Wow64PrepareForException
L2  kernelbase.dll ghost                 «рядом» с VirtualProtect
L3  ntdll.dll   ghost                    «рядом» с RtlCreateUserThread
L4  win32u.dll  NOP gap                  все известные правила его исключают
L5  ntdll!RtlUserThreadStart+0x21        корень потока
```

Все адреса ищутся **в рантайме** сканированием `.pdata` загруженного образа —
ничего не захардкожено под конкретный билд.

## Состав

```
lacuna-chain/
├── src/lacuna.cpp     # PoC (демо): scan / verify / mfprobe
├── build.sh           # кросс-сборка через zig (Windows x64)
├── deploy.sh          # заливка на VM (guestcontrol copyto) + запуск
├── run-demo.bat       # запуск scan+verify прямо на VM
└── README.md
```

Это **демонстрация** (в отличие от оригинального репозитория здесь нет
`inject`/`lacuna_sleep`): PoC ничего не инжектит, только перечисляет лакуны,
строит цепочку и разматывает её тем же путём, что и EDR/kernel stack collector
(`RtlLookupFunctionEntry` + `RtlVirtualUnwind`).

## Сборка

Нужен только [zig](https://ziglang.org) — как в `cet-shadow-stack`:

```bash
cd lacuna-chain
./build.sh          # -> out/lacuna.exe
```

## Развёртывание и запуск на стенде

Стенд: VirtualBox-VM `Windows10Kasper` (Windows 10 22H2, build 19045).

```bash
./deploy.sh scan      # залить и прогнать scan
./deploy.sh verify    # залить и прогнать verify
```

Либо на самой VM: `run-demo.bat`.

## Что видно (реальный вывод со стенда)

`lacuna.exe scan` — перечисление лакун:

```
[*] .pdata lacunae across the loaded images

  ntdll.dll         lacunae=4028   ghost-funcs=560    (45613 bytes of code)  largest=1480B
  kernelbase.dll    lacunae=4453   ghost-funcs=449    (56619 bytes of code)  largest=8895B
      ghost gadget JMP [RBX] : 00007ffababfd8c2  (kernelbase.dll ghost @7ffababfd894)
  wow64.dll         lacunae=1060   ghost-funcs=27     (1744 bytes of code)   largest=303B
  win32u.dll        lacunae=1316   ghost-funcs=1      (24 bytes of code)     largest=24B
  win32u NOP gap        : 00007ffabb371048
```

`lacuna.exe verify` — сборка цепочки и обход «глазами EDR»:

```
[*] composed ghost chain (all addresses located at runtime)

      L0  00007ffabd490f3b  ntdll.dll         BYOUD-MF anchor (UWOP_PUSH_MACHFRAME)
      L1  00007ffabbe69c82  wow64.dll         ghost / wow64 exception-prep shadow
      L2  00007ffababfd8c2  KERNELBASE.dll    ghost / VirtualProtect return-site cover
      L3  00007ffabd445fb3  ntdll.dll         ghost / thread-creation semantic layer
      L4  00007ffabb371048  win32u.dll        win32u NOP gap (whitelist-immune)
      L5  00007ffabd4426a1  ntdll.dll         RtlUserThreadStart+0x21 (thread root)

[*] gap validation - RtlLookupFunctionEntry on each ghost layer

      [+] L0 MF anchor 00007ffabd490f3b  inside a function
      [+] L1 ghost     00007ffabbe69c82  leaf (no RUNTIME_FUNCTION)
      [+] L2 ghost     00007ffababfd8c2  leaf (no RUNTIME_FUNCTION)
      [+] L3 ghost     00007ffabd445fb3  leaf (no RUNTIME_FUNCTION)
      [+] L4 nop gap   00007ffabb371048  leaf (no RUNTIME_FUNCTION)
      [+] L5 root      00007ffabd4426a1  inside a function

[*] pass 1 - BYOUD-Gap (every ghost frame is a leaf, RSP+=8)
      0    00007ffabbe69c82 wow64.dll        GHOST (leaf, RSP+=8)   L1 wow64 ghost
      1    00007ffababfd8c2 KERNELBASE.dll   GHOST (leaf, RSP+=8)   L2 kernelbase ghost
      2    00007ffabd445fb3 ntdll.dll        GHOST (leaf, RSP+=8)   L3 ntdll ghost
      3    00007ffabb371048 win32u.dll       GHOST (leaf, RSP+=8)   L4 win32u nop gap
      4    00007ffabd4426a1 ntdll.dll        rf  (function)         L5 RtlUserThreadStart+0x21
      [+] 5/5 layers reached

[*] pass 2 - BYOUD-MF (UWOP_PUSH_MACHFRAME teleports RSP in one frame)
      0    00007ffabd490f3b ntdll.dll        rf  (function)         L0 mf anchor (KiUserExceptionDispatcher)
      1    00007ffabbe69c82 wow64.dll        GHOST (leaf, RSP+=8)   L1 wow64 ghost
      ...
      5    00007ffabd4426a1 ntdll.dll        rf  (function)         L5 RtlUserThreadStart+0x21
      [+] 6/6 layers reached

 [+] plain ghost chain (5/5) clean
 [+] BYOUD-MF teleport    (6/6) clean
```

**Каждый кадр — в подписанном модуле Microsoft, и ни один байт `.pdata` не
изменён: лакуны там были всегда.**

## Почему это ломает защиту (по статье)

| Слой детекта | Итог | Почему |
|---|---|---|
| module-of-origin (первый кадр) | обойдён | L1..L4 — ntdll / kernelbase / wow64 / win32u |
| корректность unwind-обхода | обойдён | ghost-кадры — валидные leaf (`RSP+=8`) |
| форензика `.pdata` | обойдён | модификаций нет, лакуны предсуществуют |
| CET shadow stack | обойдён | чисто leaf-цепочка, return-адреса на RSP не подменяются |
| семантика кадров | обойдена | ореол `VirtualProtect` / thread-start внутри подписанной DLL |
| исключения для `win32u` | обойдены | L4 подпадает под существующие whitelist-правила |

## Ограничения и грабли стенда

- **Kaspersky на стенде режет сырой бинарь.** `C:\ProgramData\lacuna\lacuna.exe`
  определяется как `HEUR:Trojan.Win64.Inject.gen` и берётся под жёсткий лок
  (даже чтение/копирование — `Sharing violation`). Эвристика срабатывает на
  строки API-инжекта, которые PoC использует только для `GetProcAddress` при
  сканировании (`WriteProcessMemory`, `CreateRemoteThreadEx`, `NtCreateThreadEx`
  и т.п.). Это *статический* детект, к call-stack-спуфингу отношения не имеет.
  Для запуска добавьте исключение для `C:\ProgramData\lacuna` (или приостановите
  защиту). Забавная деталь для слайда: у автора в статье Kaspersky «обойдён»,
  но сам паблик-PoC теперь ловится по сигнатуре.
- **BYOUD-MF ControlPc зависит от билда.** В статье `KiUserExceptionDispatcher+4`
  (Win11 22H2). На Win10 19045 эта MF-функция не срабатывает — нужен другой
  кадр. Поэтому PoC **подбирает MF-якорь в рантайме**: проходит по всем
  функциям с `UWOP_PUSH_MACHFRAME` и берёт тот `ControlPc`, при котором весь
  downstream-чейн реально разматывается (самопроверка через `RtlVirtualUnwind`).
  Диагностика — `lacuna.exe mfprobe`:
  ```
  func 00007ffabd490d80-00007ffabd490df8  prolog=0  codes=39  mfoff=0
  func 00007ffabd490e90-00007ffabd490ecb  prolog=0  codes=2   mfoff=0
  func 00007ffabd490ee0-00007ffabd490f3c  prolog=0  codes=41  mfoff=0
  func 00007ffabd491760-00007ffabd49192c  prolog=0  codes=41  mfoff=0
  ```
- **`wow64.dll` и `win32u.dll` не всегда загружены** — PoC подтягивает их
  `LoadLibrary`, иначе `GetModuleHandle` даёт NULL.
- **Голые адреса лакун — это не «непоймать».** Как только defender начнёт
  помечать кадры, попадающие в `.pdata`-щели, техника гаснет (см. ниже).
- **`VBoxManage guestcontrol`** иногда теряет stdout — в `deploy.sh`/сценариях
  вывод пишется в файл.

## Обнаружение (для SOC / detection engineering)

Открытая задача №1 из статьи — обнаружение gap-адресов в рантайме; в PoC её
можно посмотреть «с другой стороны»:

1. **Gap-address detection.** На каждом кадре call stack проверить:
   `RtlLookupFunctionEntry(frame) == NULL`, но адрес лежит внутри модуля
   (между секциями подписанного образа). Легитимные программы почти никогда
   не имеют адресов возврата в `.pdata`-щелях. Реализуется перечислением всех
   лакун загруженных DLL (`scan` в этом PoC показывает, как их собрать) и
   сверкой с адресами из `STACKWALK`.
2. **Win32u-whitelist больше не защита.** Правило `call_trace startswith win32u.dll`
   теперь работает *против* защищающегося (NOP-gap цепочка), его надо пересмотреть.
3. **ETW-Ti APC queue depth.** Если считать, сколько ETW-Ti APC скопилось до
   alertable-wait, большое число (>3) — аномалия.
4. **Поведенческая корреляция.** Единственный оставшийся слой по статье —
   корреляция kernel callbacks (`AllocVM + WriteVM + ProtectVM + QueueAPC`).

В терминах MITRE ATT&CK: `T1562.001` (Impair Defenses), `T1620` (Reflective Code
Loading), `T1027` (Obfuscated Files or Information).

## Источники

- Mohamed Alzhrani (0xmaz) — *LACUNA Chain: Ghost Frames* (2026) + PoC
  `MazX0p/LACUNA-Chain`.
- klezVirus — *Fantastic Unwind Information and Where to Find Them* (BYOUD),
  Black Hat Europe 2025; SilentMoonwalk.
- WithSecure Labs — *Spoofing Call Stacks to Confuse EDRs* (2022).
- Microsoft — x64 exception handling / `UNWIND_INFO`, `UWOP_PUSH_MACHFRAME`.

## Дисклеймер

Только для авторизованных исследований и лабораторных стендов. Техника
использует штатные механизмы ОС; запуск вне своего контролируемого стенда —
противозаконно.
