#!/usr/bin/env bash
#
# Cross-compile the LACUNA Chain (Ghost Frames) PoC for Windows with zig.
# Produces out/lacuna.exe (x86_64, console). Same toolchain as cet-shadow-stack.
#
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$here/out"

echo "[*] building lacuna.exe"
zig c++ -target x86_64-windows-gnu -O2 -std=gnu++17 \
    -o "$here/out/lacuna.exe" \
    "$here/src/lacuna.cpp" \
    -lntdll

echo "[*] done:"
ls -la "$here/out"
