@echo off
rem ---------------------------------------------------------------------------
rem  LACUNA Chain (Ghost Frames) PoC - run directly on the Windows lab VM.
rem ---------------------------------------------------------------------------
setlocal
cd /d "%~dp0"

echo [*] 1/2 enumerating .pdata lacunae across the loaded images...
lacuna.exe scan

echo.
echo [*] 2/2 building the ghost chain and walking it like an EDR...
lacuna.exe verify

pause
