@echo off
rem ---------------------------------------------------------------------------
rem  BTR Reforged PoC - run directly on the Windows lab VM (as Administrator).
rem ---------------------------------------------------------------------------
setlocal
cd /d "%~dp0"

echo [*] 1/3 scan   - extract + verify BTR.sys from MpEngine.dll
btrpoc.exe scan

echo.
echo [*] 2/3 verify - build a transaction, print + RC4-encrypt it (no load)
btrpoc.exe verify

echo.
echo [*] 3/3 demo   - benign end-to-end run (loads BTR.sys on self-owned targets)
btrpoc.exe demo

pause
