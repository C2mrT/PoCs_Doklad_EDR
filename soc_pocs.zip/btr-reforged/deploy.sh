#!/usr/bin/env bash
#
# Deploy the BTR PoC to the Windows lab VM and run a command.
# Uses guestcontrol copyto (SMB may be firewalled off on the guest).
#
#   VM=Windows10Kasper ./deploy.sh scan
#   VM=Windows10Kasper ./deploy.sh verify
#   VM=Windows10Kasper ./deploy.sh demo
#
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"

VM="${VM:-Windows10Kasper}"
VMUSER="${VMUSER:-Administrator}"
VMPASS="${VMPASS:-Passw0rd!}"
DEST_WIN='C:\ProgramData\btrpoc'
DEST_UNIX='ProgramData/btrpoc'

mkdir -p "$here/out"
[ -f "$here/out/btrpoc.exe" ] || "$here/build.sh"

echo "[*] creating $DEST_WIN and uploading btrpoc.exe"
VBoxManage guestcontrol "$VM" run --exe 'C:\Windows\System32\cmd.exe' \
    --username "$VMUSER" --password "$VMPASS" -- /c "mkdir $DEST_WIN 2>nul" >/dev/null 2>&1 || true
VBoxManage guestcontrol "$VM" copyto --username "$VMUSER" --password "$VMPASS" \
    "$here/out/btrpoc.exe" "$DEST_WIN\\btrpoc.exe" >/dev/null
echo "[*] done: $DEST_WIN\\btrpoc.exe"

if [ -n "${1:-}" ]; then
    echo "[*] running 'btrpoc.exe $1' on the guest..."
    VBoxManage guestcontrol "$VM" run --exe 'C:\Windows\System32\cmd.exe' \
        --username "$VMUSER" --password "$VMPASS" -- /c \
        "$DEST_WIN\\btrpoc.exe $1 > $DEST_WIN\\out.txt 2>&1 & type $DEST_WIN\\out.txt"
fi
