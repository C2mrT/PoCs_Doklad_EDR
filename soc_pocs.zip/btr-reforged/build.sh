#!/usr/bin/env bash
#
# Cross-compile the "BTR Reforged" PoC for Windows with zig.
# Produces out/btrpoc.exe (x86_64, console). Same toolchain as the other PoCs.
#
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$here/out"

echo "[*] building btrpoc.exe"
zig c++ -target x86_64-windows-gnu -O2 -std=gnu++17 \
    -o "$here/out/btrpoc.exe" \
    "$here/src/btrpoc.cpp" \
    -ladvapi32 -lntdll

echo "[*] done:"
ls -la "$here/out"
