# BTR Reforged PoC — `BTR.sys` как подписанный Ring-0 примитив

Рабочий PoC техники **BTR Reforged**: злоупотребление драйвером Windows Defender
**`BTR.sys`** (Boot Time Removal Tool) как «LOLDriver» — подписанный Microsoft,
встроенный в систему, устойчивый к WDAC kernel-примитив для файловых и
реестровых операций из Ring-0.

Публичное исследование: **Jiří Vinopal (@Dump-GUY), Check Point Research** —
*«BTR Reforged: Weaponizing Defender's Remediation Driver as a Kernel Operation
Primitive»* (Black Hat USA 2026 / DEF CON 34). Референсный инструмент —
[`Dump-GUY/BTR_CLI`](https://github.com/Dump-GUY/BTR_CLI) (MIT).

Блок доклада: «Когда защита становится оружием: LOLDrivers».

> **Рамка этого PoC.** Это **демонстрация протокола и пайплайна**, а не
> EDR-killer. Реализованы разбор `MpEngine.dll`, извлечение `BTR.sys`, сборка
> RC4/CRC-транзакции, стейджинг в ADS, создание сервиса и загрузка через
> `NtLoadDriver`, разбор отчёта. Демо-операции — **только свои, безобидные
> цели** (`C:\ProgramData\btrpoc` и `HKLM\SOFTWARE\BTRPoC`). Реальный
> кейс-килл-чейн (удаление `WdFilter.sys` / `MsMpEng.exe` / ключей Defender из
> Ring-0) **намеренно не реализован** — см. «Обнаружение».

## Идея

`BTR.sys` — «одноразовый» драйвер, который Defender дропает при ремедиации,
требующей перезагрузки (например, удалить заблокированный файл). Он встроен как
PE-ресурс в `MpEngine.dll` и вынимается на диск со случайным именем
(`[a-z]{8}.sys`). У драйвера **нет IOCTL-интерфейса** — он читает конфигурацию
из ADS `"<драйвер>.sys:changelist"`, путь к которой задан значением `Args` его
service-ключа.

Протокол транзакции (реверс из статьи):

| Слой | Детали |
|---|---|
| **Global Header (24 Б)** | `Magic=0xFEE1DEAD`, `Version=2`, `PayloadOffset=0x10`, `GlobalCRC`, `TransID` (`Low=~CRC32(payload)`, `High=size(payload)`) |
| **Global Payload** | путь к *feedback*-файлу (UTF-16, null-terminated) |
| **Item Header (16 Б) ×N** | `DataSize`, `ActionID`, `HeaderCRC`, `DataCRC` |
| **Item Data** | `[Flags(4)] [строки/поля] [4 нулевых байта padding]` |
| **Крипто** | весь blob — **RC4**, 256-байтный ключ в `.rdata` (одинаков во всех сборках с Win7) |
| **Целостность** | **~CRC32**: стандартный `0xEDB88320`, init `0xFFFFFFFF`, **без финального XOR**; CRC сбрасывается для каждой структуры отдельно |

Пять шагов реверса упираются в это; реализованные в PoC `ActionID`:

| ID | примитив | структура |
|---|---|---|
| 1 | Delete File (обходит локи) | `[Path]` |
| 2 | Delete Directory (пустой) | `[Path]` |
| 3 | Move / Quarantine | `[Flags][Src][Dst]` (пустой Dst = удаление) |
| 4 | Delete Registry Key | `[Flags][Key]` |
| 5 | Delete Registry Value | `[Flags][Key + "\\" + Value]` |
| 6 | Set Registry Value (+ создаёт ключ) | `[Flags][Type][Size][Key\\Value][Data]` |

Пайплайн (как у Defender): извлечь драйвер → записать RC4-конфиг в ADS
`random.sys:changelist` → создать transient service-ключ (`Type=1, Start=1,
ErrorControl=0, Group="Boot Bus Extender"`, `Args=<ADS>`) → `NtLoadDriver` →
драйвер выполняет items, пишет отчёт в `random.sys:random.dat`, возвращает
`STATUS_DELETE_PENDING` (`0xC0000056`) и самовыгружается → очистка.

## Состав

```
btr-reforged/
├── src/btrpoc.cpp     # PoC (демо): scan / verify / demo
├── build.sh           # кросс-сборка через zig (Windows x64)
├── deploy.sh          # заливка через guestcontrol copyto + запуск
├── run-demo.bat       # запуск scan+verify+demo на VM
└── README.md
```

Только Win32 API + `advapi32`/`ntdll`; падение на embedded-`BTR.sys` не нужно —
драйвер берётся из локального `MpEngine.dll` (fallback из репо `BTR_CLI` я
специально не тащу: это бинарь Microsoft).

## Сборка

```bash
cd btr-reforged
./build.sh          # -> out/btrpoc.exe
```

## Развёртывание и запуск на стенде

Стенд: VirtualBox-VM `Windows10Kasper` (Windows 10 22H2, build 19045).
**Нужен локальный администратор** (включается `SeLoadDriverPrivilege`).

```bash
./deploy.sh scan      # извлечь и проверить BTR.sys
./deploy.sh verify    # протокол: собрать/распечатать/зашифровать транзакцию
./deploy.sh demo      # безобидный end-to-end прогон (грузит драйвер)
```

Либо на самой VM: `run-demo.bat`.

## Что видно (реальный вывод со стенда)

`scan` — извлечение и проверка драйвера:

```
[*] MpEngine.dll : C:\ProgramData\Microsoft\Windows Defender\Definition Updates\Default\MpEngine.dll

// [1] extracted driver
      path             : C:\ProgramData\btrpoc\BTR.sys
      size             : 72816 bytes
      FileDescription  : present
      OriginalFilename : present
      MS signature     : present (certificate table)
      RC4 key in .rdata: MATCHED
```

`verify` — структура транзакции (без загрузки):

```
      Magic          : 0xFEE1DEAD
      Version        : 2
      PayloadOffset  : 0x10
      GlobalCRC      : 0x4A9186FE   (~CRC32 over header, CRC field zeroed)
      TransID_Low    : 0xC62860AE   (~CRC32 of feedback path)
      TransID_High   : 0x00000060   (byte size of feedback path)
      item 0: action=1 dataSize=66   headerCRC=0xBE4D482C dataCRC=0x726A98A0
      item 1: action=1 dataSize=78   headerCRC=0xFFC5EA14 dataCRC=0xFF756AF8
      item 2: action=6 dataSize=104  headerCRC=0xC3F8906E dataCRC=0xB8EB769E
      item 3: action=4 dataSize=76   headerCRC=0x89D30CE7 dataCRC=0xEDF4AFDC
```

`demo` — реальная загрузка драйвера на своих целях:

```
[+] BTR.sys staged at C:\ProgramData\btrpoc\sjytlhxn.sys (72816 bytes)
[+] RC4 config (688 bytes) written to ADS C:\ProgramData\btrpoc\sjytlhxn.sys:changelist
[+] transient service key created: HKLM\SYSTEM\CurrentControlSet\Services\sjytlhxn
[*] NtLoadDriver ...
[+] NtLoadDriver returned 0xC0000056  (STATUS_DELETE_PENDING = BTR.sys did its work and self-unloaded)

      per-item NTSTATUS (from the driver):
      action 4 (DeleteKey      ) dataSize 122  STATUS 0x00000000  success
      action 1 (DeleteFile     ) dataSize 66   STATUS 0x00000000  success
      action 3 (Move/Quarantine) dataSize 156  STATUS 0x00000000  success
      action 1 (DeleteFile     ) dataSize 78   STATUS 0x00000000  success
      action 6 (SetValue       ) dataSize 104  STATUS 0x00000000  success
      action 4 (DeleteKey      ) dataSize 76   STATUS 0x00000000  success

[*] effects (verified from user mode)
      victim.txt deleted           : YES
      moved.txt created (move)     : YES
      HKLM\SOFTWARE\BTRPoC removed : YES
[+] cleaned up (driver, service key, ADS, artefacts)
```

Все операции выполнены **из Ring-0** (удаление файла обходит локи, перемещение и
запись/удаление ключа — без user-mode API). Возврат `0xC0000056` — сигнал ядру
выгрузить драйвер; в логе он остаётся как `System` (PID 4).

## Почему это ломает защиту (по статье)

- **Файловая система:** удаление и запись файлов из Ring-0 — обход эксклюзивных
  локов и user-mode политик.
- **Tamper Protection:** применяется к user-mode процессам; операции драйвера —
  ядерные, поэтому ключи сервисов защитных продуктов удаляются на рантайме.
- **WDAC / Vulnerable Driver Blocklist** не помогают: `BTR.sys` — *встроенный*
  компонент Windows, а не сторонний уязвимый драйвер. Не BYOVD.
- **ELAM:** `BTR.sys` исполняется в post-ELAM (`Start=1`), проверками boot-start
  драйверов не оценивается.
- **«Golden Window» (boot-time):** при `Start=1` + группа `Boot Bus Extender`
  драйвер исполняется в начале Phase 1 — файловая система уже пишется, а
  user-mode сервисы защиты (MsMpEng и т.п.) ещё не стартовали.

## Ограничения и грабли стенда

- **Нужен администратор** и `SeLoadDriverPrivilege` (PoC включает привилегию сам).
- **Нужен `MpEngine.dll`** с непропатченным ресурсом `PACKEDBINARY/BOOTTIMETOOL`.
  На стенде он лежит в
  `C:\ProgramData\Microsoft\Windows Defender\Definition Updates\Default\MpEngine.dll`
  (ресурс — сырой PE, 72816 Б, оффсет `0xd17860`).
- **Формат отчёта не совпадает с конфигом.** Отчёт (ADS `<rand>.sys:<rand>.dat`)
  тоже RC4-зашифрован, но **не содержит Global Payload** — после 24-байтного
  заголовка сразу идут items, а первые 4 байта каждого item data заменены на
  `NTSTATUS`. Плюс драйвер дописывает item самоочистки своего service-ключа.
  PoC это учитывает (см. `ParseReport`).
- **`Args` в service-ключе = DOS-путь к ADS** (`C:\...\rand.sys:changelist`),
  `ImagePath` = `\??\C:\...\rand.sys`. Оба нормализуются `ToNtPath`.
- **Kaspersky на стенде** ловит сырой бинарь (как и `lacuna.exe`) — для запуска
  нужно исключение на `C:\ProgramData\btrpoc` либо приостановленная защита.
- **SMB на стенде отвалился** после отключения Kaspersky (поднялся Windows
  Firewall) — `deploy.sh` использует канал `guestcontrol copyto`.

## Обнаружение (для SOC / detection engineering)

Детект из статьи (сигнатура тут бесполезна — драйвер подписан Microsoft):

1. **ADS-аномалии — Sysmon ID 15 (высокая точность).**
   `TargetFilename` заканчивается на `.sys:changelist`. В легитиме engine пишет
   feedback в `C:\ProgramData\Microsoft\Windows Defender\Scans\RebootActions\`;
   PoC/атакующий — во **вторичный ADS на самом `.sys`** (`.sys:<rand>.dat`).
   Это ключевой различающий признак.
2. **Kernel-mode execution context — Sysmon ID 23.**
   Удаление файла логируется как `Image: System (PID 4)`, а не как вызвавший
   процесс. Коррелировать с `DriverLoad` (ID 6) незадолго до.
3. **Driver deployment & lineage — Sysmon ID 6.**
   `DriverLoad` подписанного `BTR.sys`, но `ParentImage`/источник — вне
   экосистемы Defender (`cmd.exe`, `powershell.exe`, неизвестный бинарь).
4. **Stealth registry staging — ID 12/13 vs Event ID 7045.**
   Атакующий пишет service-ключ напрямую в реестр + `NtLoadDriver` → стандартное
   событие `7045` **не** появляется. Искать создание service-ключа с `Args`,
   содержащим `:changelist`, и `Group = "Boot Bus Extender"` без `7045`.
5. **Anti-forensics — ID 11 & 23.** Быстрое создание и удаление
   `\SystemRoot\Temp\BootClean.log` процессом `System` (PID 4) — жёстко зашито в
   драйвере, происходит всегда.
6. **Hardening:** ограничивать и мониторить выдачу/использование
   `SeLoadDriverPrivilege`.

MITRE ATT&CK: `T1562.001` (Impair Defenses), `T1543.003` (Create/Modify System
Service), `T1014` (Rootkit), `T1070.004` (Indicator Removal).

## Источники

- Check Point Research — *BTR Reforged* (2026), Jiří Vinopal.
- `Dump-GUY/BTR_CLI` (MIT) — референсная реализация протокола.
- MSRC: не будут патчить (требуется `SeLoadDriverPrivilege`).

## Дисклеймер

Только для авторизованных исследований и лабораторных стендов. Техника требует
прав администратора и опирается на встроенный компонент ОС — это не 0-day и не
CVE. Запуск на чужих системах противозаконен. PoC намеренно не содержит
EDR/AV-нейтрализующего payload.
